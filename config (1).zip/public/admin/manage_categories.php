<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$current_restaurant_name_from_session = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name']) : 'المطعم';

$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
$message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

$sections_for_dropdown = [];
$stmt_get_sections_dropdown = $conn->prepare("SELECT id, name FROM menu_sections WHERE restaurant_id = ? ORDER BY display_order ASC, name ASC");
if($stmt_get_sections_dropdown){
    $stmt_get_sections_dropdown->bind_param("i", $restaurant_id);
    $stmt_get_sections_dropdown->execute();
    $result_sections_dropdown = $stmt_get_sections_dropdown->get_result();
    if ($result_sections_dropdown->num_rows > 0) {
        while ($row = $result_sections_dropdown->fetch_assoc()) {
            $sections_for_dropdown[] = $row;
        }
    }
    $stmt_get_sections_dropdown->close();
} else {
    $message = "خطأ في جلب قائمة الأقسام للإضافة."; $message_type="error";
    error_log("SQL Error (get sections for dropdown): " . $conn->error);
}


$categories = [];
$sql_get_categories = "
    SELECT mc.id, mc.name, mc.display_order, mc.is_visible, ms.name AS section_name 
    FROM menu_categories mc
    JOIN menu_sections ms ON mc.menu_section_id = ms.id
    WHERE ms.restaurant_id = ? 
    ORDER BY ms.display_order ASC, ms.name ASC, mc.display_order ASC, mc.name ASC";
    
$stmt_get_categories = $conn->prepare($sql_get_categories);
if($stmt_get_categories){
    $stmt_get_categories->bind_param("i", $restaurant_id);
    $stmt_get_categories->execute();
    $result_categories = $stmt_get_categories->get_result();
    if ($result_categories->num_rows > 0) {
        while ($row = $result_categories->fetch_assoc()) {
            $categories[] = $row;
        }
    }
    $stmt_get_categories->close();
} else {
    $message = "خطأ في جلب قائمة التصنيفات."; $message_type="error";
    error_log("SQL Error (get categories list): " . $conn->error);
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة تصنيفات المنيو - <?php echo $current_restaurant_name_from_session; ?></title>
    <link rel="stylesheet" href="css/admin_styles.css"> 
</head>
<body>

    <nav class="navbar">
        <h1>لوحة تحكم: <?php echo $current_restaurant_name_from_session; ?></h1>
        <a href="logout.php">تسجيل الخروج</a>
    </nav>

    <div class="main-container">
        <aside class="sidebar">
            <h2>القائمة الرئيسية</h2>
            <ul>
                <li><a href="dashboard.php">لوحة التحكم الرئيسية</a></li>
                <li><a href="manage_sections.php">إدارة أقسام المنيو</a></li>
                <li><a href="manage_categories.php" class="active">إدارة تصنيفات المنيو</a></li>
                <li><a href="manage_items.php">إدارة أصناف المنيو</a></li>
                <li><a href="view_orders.php">عرض الطلبات</a></li>
            </ul>
        </aside>

        <main class="content-area">
            <div class="page-header">
                <h2>إدارة تصنيفات المنيو</h2>
            </div>

            <?php if (!empty($message)): ?>
                <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
            <?php endif; ?>

            <div class="form-section">
                <h3>إضافة تصنيف جديد</h3>
                <?php if (!empty($sections_for_dropdown)): ?>
                    <form action="handle_add_category.php" method="POST">
                        <label for="menu_section_id">اختر القسم:</label>
                        <select id="menu_section_id" name="menu_section_id" required>
                            <option value="">-- اختر قسم --</option>
                            <?php foreach ($sections_for_dropdown as $section): ?>
                                <option value="<?php echo $section['id']; ?>"><?php echo htmlspecialchars($section['name']); ?></option>
                            <?php endforeach; ?>
                        </select>

                        <label for="category_name">اسم التصنيف:</label>
                        <input type="text" id="category_name" name="category_name" required>

                        <label for="display_order">ترتيب العرض:</label>
                        <input type="number" id="display_order" name="display_order" value="0" min="0" required>
                        
                        <label for="is_visible">الحالة:</label>
                        <select id="is_visible" name="is_visible">
                            <option value="1" selected>ظاهر</option>
                            <option value="0">مخفي</option>
                        </select>

                        <input type="submit" name="add_category" value="إضافة التصنيف">
                    </form>
                <?php else: ?>
                    <p class="no-data">يجب عليك <a href="manage_sections.php">إضافة قسم واحد على الأقل</a> قبل أن تتمكن من إضافة تصنيفات.</p>
                <?php endif; ?>
            </div>

            <div class="data-table-container" style="margin-top: 30px;">
                <h3>التصنيفات الحالية</h3>
                <?php if (!empty($categories)): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>اسم التصنيف</th>
                                <th>يتبع لقسم</th>
                                <th>ترتيب العرض</th>
                                <th>الحالة</th>
                                <th>إجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($categories as $category): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($category['name']); ?></td>
                                <td><?php echo htmlspecialchars($category['section_name']); ?></td>
                                <td><?php echo htmlspecialchars($category['display_order']); ?></td>
                                <td><?php echo $category['is_visible'] ? 'ظاهر' : 'مخفي'; ?></td>
                                <td class="action-links">
                                    <a href="edit_category.php?id=<?php echo $category['id']; ?>" class="edit">تعديل</a>
                                    <a href="delete_category.php?id=<?php echo $category['id']; ?>" class="delete" onclick="return confirm('هل أنت متأكد من رغبتك في حذف هذا التصنيف؟ سيتم حذف جميع الأصناف التابعة له أيضًا.');">حذف</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="no-data">لا توجد تصنيفات حاليًا. قم بإضافة تصنيف جديد أعلاه.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>