<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: manage_items.php?message=unauthorized&message_type=error");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];

// التحقق من أن الطلب هو POST ومن أن زر التعديل قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_item'])) {

    // الحصول على البيانات من النموذج
    $item_id = filter_input(INPUT_POST, 'item_id', FILTER_VALIDATE_INT);
    $menu_category_id = filter_input(INPUT_POST, 'menu_category_id', FILTER_VALIDATE_INT);
    $item_name = trim($_POST['item_name']);
    $description = trim($_POST['description']);
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $image_url = trim($_POST['image_url']);
    $display_order = filter_input(INPUT_POST, 'display_order', FILTER_VALIDATE_INT);
    $is_available = filter_input(INPUT_POST, 'is_available', FILTER_VALIDATE_INT);

    // التحقق الأساسي من المدخلات
    if ($item_id === false || $item_id <= 0) {
        header("Location: manage_items.php?message=معرف الصنف غير صالح للتحديث.&message_type=error");
        exit();
    }
    if ($menu_category_id === false || $menu_category_id <= 0) {
        header("Location: edit_item.php?id=" . $item_id . "&message=الرجاء اختيار تصنيف صالح.&message_type=error");
        exit();
    }
    if (empty($item_name)) {
        header("Location: edit_item.php?id=" . $item_id . "&message=اسم الصنف مطلوب.&message_type=error");
        exit();
    }
    if ($price === false || $price < 0) {
        header("Location: edit_item.php?id=" . $item_id . "&message=السعر المدخل غير صالح.&message_type=error");
        exit();
    }

    // التحقق من أن التصنيف المختار (menu_category_id) يتبع لمطعم المستخدم
    $stmt_check_category_owner = $conn->prepare(
        "SELECT mc.id 
         FROM menu_categories mc
         JOIN menu_sections ms ON mc.menu_section_id = ms.id
         WHERE mc.id = ? AND ms.restaurant_id = ?"
    );
    if ($stmt_check_category_owner) {
        $stmt_check_category_owner->bind_param("ii", $menu_category_id, $restaurant_id);
        $stmt_check_category_owner->execute();
        $stmt_check_category_owner->store_result();
        if ($stmt_check_category_owner->num_rows == 0) {
            $stmt_check_category_owner->close();
            header("Location: edit_item.php?id=" . $item_id . "&message=التصنيف المختار غير صالح أو لا تملكه.&message_type=error");
            exit();
        }
        $stmt_check_category_owner->close();
    } else {
        error_log("SQL Error (check category ownership for edit item): " . $conn->error);
        header("Location: edit_item.php?id=" . $item_id . "&message=خطأ في التحقق من ملكية التصنيف.&message_type=error");
        exit();
    }
    
    // التحقق من صحة رابط الصورة (إذا تم إدخاله)
    if (!empty($image_url) && !filter_var($image_url, FILTER_VALIDATE_URL)) {
        header("Location: edit_item.php?id=" . $item_id . "&message=رابط الصورة غير صالح.&message_type=error");
        exit();
    }
    if (empty($image_url)) {
        $image_url = null;
    }
    if (empty($description)) {
        $description = null;
    }

    if ($display_order === false || $display_order < 0) {
        $display_order = 0;
    }
    if ($is_available === null || !in_array($is_available, [0, 1])) {
        $is_available = 1;
    }

    // إعداد استعلام SQL لتحديث البيانات
    // نتحقق من ملكية الصنف بشكل غير مباشر من خلال التأكد أن صفحة edit_item.php لم تعرض إلا الأصناف المملوكة
    // والآن تحققنا أن التصنيف الجديد الذي سيتم ربط الصنف به هو أيضاً مملوك.
    $stmt_update_item = $conn->prepare(
        "UPDATE menu_items 
         SET name = ?, description = ?, price = ?, image_url = ?, display_order = ?, is_available = ?, menu_category_id = ?
         WHERE id = ?" 
         // لا يمكن إضافة AND ms.restaurant_id = ? هنا بسهولة بدون JOIN إضافي في UPDATE
         // لذا الأمان يعتمد على التحقق السابق وعلى أن edit_item.php عرض الصنف الصحيح
    );
    
    if ($stmt_update_item) {
        $stmt_update_item->bind_param("ssdsiiii", 
            $item_name, 
            $description, 
            $price, 
            $image_url, 
            $display_order, 
            $is_available, 
            $menu_category_id,
            $item_id 
        );

        if ($stmt_update_item->execute()) {
            // نجح التحديث
            if ($stmt_update_item->affected_rows > 0) {
                $message = "تم تحديث الصنف بنجاح.";
                $message_type = "success";
            } else {
                // لم يتم تحديث أي صفوف، قد يعني أن البيانات لم تتغير
                $message = "لم يتم إجراء أي تغييرات على الصنف.";
                $message_type = "info"; 
            }
            $stmt_update_item->close();
            $conn->close();
            header("Location: manage_items.php?message=" . urlencode($message) . "&message_type=" . urlencode($message_type));
            exit();
        } else {
            // فشل التحديث
            error_log("SQL Error in handle_edit_item (execute): " . $stmt_update_item->error);
            $stmt_update_item->close();
            $conn->close();
            header("Location: edit_item.php?id=" . $item_id . "&message=فشل في تحديث الصنف. خطأ في التنفيذ: " .urlencode($stmt_update_item->error) . "&message_type=error");
            exit();
        }
    } else {
        // فشل في إعداد الاستعلام
        error_log("SQL Error in handle_edit_item (prepare): " . $conn->error);
        $conn->close();
        header("Location: edit_item.php?id=" . $item_id . "&message=فشل في إعداد عملية تحديث الصنف.&message_type=error");
        exit();
    }

} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر التعديل، يتم توجيه المستخدم
    header("Location: manage_items.php");
    exit();
}
?>