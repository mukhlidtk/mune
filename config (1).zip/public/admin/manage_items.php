<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$current_restaurant_name_from_session = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name'] ?? 'المطعم') : 'المطعم';

$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
$message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

$categories_for_dropdown = [];
$sql_get_categories_dropdown = "
    SELECT mc.id, mc.name AS category_name, ms.name AS section_name 
    FROM menu_categories mc
    JOIN menu_sections ms ON mc.menu_section_id = ms.id
    WHERE ms.restaurant_id = ? 
    ORDER BY ms.display_order ASC, ms.name ASC, mc.display_order ASC, mc.name ASC";
$stmt_get_categories_dropdown = $conn->prepare($sql_get_categories_dropdown);
if($stmt_get_categories_dropdown){
    $stmt_get_categories_dropdown->bind_param("i", $restaurant_id);
    $stmt_get_categories_dropdown->execute();
    $result_categories_dropdown = $stmt_get_categories_dropdown->get_result();
    if ($result_categories_dropdown->num_rows > 0) {
        while ($row = $result_categories_dropdown->fetch_assoc()) {
            $categories_for_dropdown[] = $row;
        }
    }
    $stmt_get_categories_dropdown->close();
} else {
    $message = "خطأ في جلب قائمة التصنيفات للإضافة."; $message_type="error";
    error_log("SQL Error (get categories for dropdown - items page): " . $conn->error);
}

$items = [];
$sql_get_items = "
    SELECT 
        mi.id, mi.name AS item_name, mi.price, mi.display_order, mi.is_available, mi.description, mi.image_url,
        mc.name AS category_name, 
        ms.name AS section_name
    FROM menu_items mi
    JOIN menu_categories mc ON mi.menu_category_id = mc.id
    JOIN menu_sections ms ON mc.menu_section_id = ms.id
    WHERE ms.restaurant_id = ? 
    ORDER BY ms.display_order ASC, ms.name ASC, mc.display_order ASC, mc.name ASC, mi.display_order ASC, mi.name ASC";
    
$stmt_get_items = $conn->prepare($sql_get_items);
if($stmt_get_items){
    $stmt_get_items->bind_param("i", $restaurant_id);
    $stmt_get_items->execute();
    $result_items = $stmt_get_items->get_result();
    if ($result_items->num_rows > 0) {
        while ($row = $result_items->fetch_assoc()) {
            $items[] = $row;
        }
    }
    $stmt_get_items->close();
} else {
    $message = "خطأ في جلب قائمة الأصناف."; $message_type="error";
    error_log("SQL Error (get items list): " . $conn->error);
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة أصناف المنيو - <?php echo $current_restaurant_name_from_session; ?></title>
    <link rel="stylesheet" href="css/admin_styles.css"> </head>
<body>
    <nav class="navbar">
        <h1>لوحة تحكم: <?php echo $current_restaurant_name_from_session; ?></h1>
        <a href="logout.php">تسجيل الخروج</a>
    </nav>
    <div class="main-container">
        <aside class="sidebar">
            <h2>القائمة الرئيسية</h2>
            <ul>
                <li><a href="dashboard.php">لوحة التحكم الرئيسية</a></li>
                <li><a href="manage_sections.php">إدارة أقسام المنيو</a></li>
                <li><a href="manage_categories.php">إدارة تصنيفات المنيو</a></li>
                <li><a href="manage_items.php" class="active">إدارة أصناف المنيو</a></li>
                <li><a href="view_orders.php">عرض الطلبات</a></li>
            </ul>
        </aside>
        <main class="content-area">
            <div class="page-header">
                <h2>إدارة أصناف المنيو</h2>
            </div>
            <?php if (!empty($message)): ?>
                <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
            <?php endif; ?>
            <div class="form-section">
                <h3>إضافة صنف جديد</h3>
                <?php if (!empty($categories_for_dropdown)): ?>
                    <form action="handle_add_item.php" method="POST">
                        <label for="menu_category_id">اختر التصنيف (القسم):</label>
                        <select id="menu_category_id" name="menu_category_id" required>
                            <option value="">-- اختر تصنيف --</option>
                            <?php foreach ($categories_for_dropdown as $category): ?>
                                <option value="<?php echo $category['id']; ?>">
                                    <?php echo htmlspecialchars($category['section_name'] . ' > ' . $category['category_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <label for="item_name">اسم الصنف:</label>
                        <input type="text" id="item_name" name="item_name" required>
                        <label for="description">وصف الصنف (اختياري):</label>
                        <textarea id="description" name="description"></textarea>
                        <label for="price">السعر:</label>
                        <input type="number" id="price" name="price" step="0.01" min="0" required>
                        <label for="image_url">رابط صورة الصنف (اختياري):</label>
                        <input type="url" id="image_url" name="image_url" placeholder="https://example.com/image.jpg">
                        <label for="display_order">ترتيب العرض:</label>
                        <input type="number" id="display_order" name="display_order" value="0" min="0" required>
                        <label for="is_available">الحالة:</label>
                        <select id="is_available" name="is_available">
                            <option value="1" selected>متوفر</option>
                            <option value="0">غير متوفر</option>
                        </select>
                        <input type="submit" name="add_item" value="إضافة الصنف">
                    </form>
                <?php else: ?>
                    <p class="no-data">يجب عليك <a href="manage_categories.php">إضافة تصنيف واحد على الأقل</a> قبل أن تتمكن من إضافة أصناف.</p>
                <?php endif; ?>
            </div>
            <div class="data-table-container" style="margin-top: 30px;">
                <h3>الأصناف الحالية</h3>
                <?php if (!empty($items)): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>الصورة</th>
                                <th>اسم الصنف</th>
                                <th>الوصف المختصر</th>
                                <th>السعر</th>
                                <th>التصنيف (القسم)</th>
                                <th>ترتيب العرض</th>
                                <th>الحالة</th>
                                <th>إجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($items as $item): ?>
                            <tr>
                                <td>
                                    <?php if (!empty($item['image_url'])): ?>
                                        <img src="<?php echo htmlspecialchars($item['image_url'] ?? ''); ?>" alt="<?php echo htmlspecialchars($item['item_name'] ?? ''); ?>" class="item-image-preview">
                                    <?php endif; ?>
                                </td>
                                <td><?php echo htmlspecialchars($item['item_name'] ?? ''); ?></td>
                                <td><small><?php 
                                    $description_text = $item['description'] ?? ''; // <<-- FIX APPLIED HERE
                                    echo nl2br(htmlspecialchars(mb_substr($description_text, 0, 70) . (mb_strlen($description_text) > 70 ? '...' : ''))); 
                                ?></small></td>
                                <td><?php echo htmlspecialchars(number_format($item['price'], 2)); ?> ر.س</td>
                                <td><?php echo htmlspecialchars($item['category_name'] ?? ''); ?> <br><small>(<?php echo htmlspecialchars($item['section_name'] ?? ''); ?>)</small></td>
                                <td><?php echo htmlspecialchars($item['display_order']); ?></td>
                                <td><?php echo $item['is_available'] ? 'متوفر' : 'غير متوفر'; ?></td>
                                <td class="action-links">
                                    <a href="edit_item.php?id=<?php echo $item['id']; ?>" class="edit">تعديل</a><br>
                                    <a href="manage_item_options.php?item_id=<?php echo $item['id']; ?>" class="options">خيارات الصنف</a><br>
                                    <a href="delete_item.php?id=<?php echo $item['id']; ?>" class="delete" onclick="return confirm('هل أنت متأكد من رغبتك في حذف هذا الصنف؟ سيتم حذف خياراته أيضًا.');">حذف</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="no-data">لا توجد أصناف حاليًا. قم بإضافة صنف جديد أعلاه.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>