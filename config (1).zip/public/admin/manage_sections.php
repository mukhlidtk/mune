<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$current_restaurant_name_from_session = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name']) : 'المطعم';

// رسائل الحالة من عمليات CRUD
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
$message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

// جلب الأقسام الحالية للمطعم
$sections = [];
$stmt_get_sections = $conn->prepare("SELECT id, name, display_order, is_visible FROM menu_sections WHERE restaurant_id = ? ORDER BY display_order ASC, name ASC");
if($stmt_get_sections){
    $stmt_get_sections->bind_param("i", $restaurant_id);
    $stmt_get_sections->execute();
    $result_sections = $stmt_get_sections->get_result();
    if ($result_sections->num_rows > 0) {
        while ($row = $result_sections->fetch_assoc()) {
            $sections[] = $row;
        }
    }
    $stmt_get_sections->close();
} else {
    $message = "خطأ في إعداد استعلام جلب الأقسام.";
    $message_type = "error";
    error_log("SQL Error (prepare get sections): " . $conn->error);
}
$conn->close();
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة أقسام المنيو - <?php echo $current_restaurant_name_from_session; ?></title>
    <link rel="stylesheet" href="css/admin_styles.css"> </head>
<body>

    <nav class="navbar">
        <h1>لوحة تحكم: <?php echo $current_restaurant_name_from_session; ?></h1>
        <a href="logout.php">تسجيل الخروج</a>
    </nav>

    <div class="main-container">
        <aside class="sidebar">
            <h2>القائمة الرئيسية</h2>
            <ul>
                <li><a href="dashboard.php">لوحة التحكم الرئيسية</a></li>
                <li><a href="manage_sections.php" class="active">إدارة أقسام المنيو</a></li>
                <li><a href="manage_categories.php">إدارة تصنيفات المنيو</a></li>
                <li><a href="manage_items.php">إدارة أصناف المنيو</a></li>
                <li><a href="view_orders.php">عرض الطلبات</a></li>
            </ul>
        </aside>

        <main class="content-area">
            <div class="page-header">
                <h2>إدارة أقسام المنيو</h2>
            </div>

            <?php if (!empty($message)): ?>
                <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
            <?php endif; ?>

            <div class="form-section">
                <h3>إضافة قسم جديد</h3>
                <form action="handle_add_section.php" method="POST">
                    <label for="section_name">اسم القسم:</label>
                    <input type="text" id="section_name" name="section_name" required>

                    <label for="display_order">ترتيب العرض (رقم أصغر يظهر أولاً):</label>
                    <input type="number" id="display_order" name="display_order" value="0" min="0" required>
                    
                    <label for="is_visible">الحالة:</label>
                    <select id="is_visible" name="is_visible">
                        <option value="1" selected>ظاهر</option>
                        <option value="0">مخفي</option>
                    </select>

                    <input type="submit" name="add_section" value="إضافة القسم">
                </form>
            </div>
            
            <div class="data-table-container" style="margin-top: 30px;">
                <h3>الأقسام الحالية</h3>
                <?php if (!empty($sections)): ?>
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>اسم القسم</th>
                                <th>ترتيب العرض</th>
                                <th>الحالة</th>
                                <th>إجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($sections as $section): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($section['name']); ?></td>
                                <td><?php echo htmlspecialchars($section['display_order']); ?></td>
                                <td><?php echo $section['is_visible'] ? 'ظاهر' : 'مخفي'; ?></td>
                                <td class="action-links">
                                    <a href="edit_section.php?id=<?php echo $section['id']; ?>" class="edit">تعديل</a>
                                    <a href="delete_section.php?id=<?php echo $section['id']; ?>" class="delete" onclick="return confirm('هل أنت متأكد من رغبتك في حذف هذا القسم؟ سيتم حذف جميع التصنيفات والأصناف التابعة له.');">حذف</a>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p class="no-data">لا توجد أقسام حاليًا. قم بإضافة قسم جديد أعلاه.</p>
                <?php endif; ?>
            </div>
        </main>
    </div>
</body>
</html>