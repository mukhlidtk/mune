<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$restaurant_name = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name']) : 'المطعم';

$item_id = null;
$item_name = '';
$item_options = [];
$error_message = '';
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
$message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

// التحقق من وجود معرّف الصنف في الرابط
if (isset($_GET['item_id'])) {
    $item_id = filter_input(INPUT_GET, 'item_id', FILTER_VALIDATE_INT);

    if ($item_id === false || $item_id <= 0) {
        $error_message = "معرّف الصنف غير صالح.";
    } else {
        // جلب اسم الصنف والتأكد من أنه يتبع للمطعم الحالي
        $stmt_get_item = $conn->prepare(
            "SELECT mi.name 
             FROM menu_items mi
             JOIN menu_categories mc ON mi.menu_category_id = mc.id
             JOIN menu_sections ms ON mc.menu_section_id = ms.id
             WHERE mi.id = ? AND ms.restaurant_id = ?"
        );
        if ($stmt_get_item) {
            $stmt_get_item->bind_param("ii", $item_id, $restaurant_id);
            $stmt_get_item->execute();
            $result_item_name = $stmt_get_item->get_result();
            if ($result_item_name->num_rows == 1) {
                $item_details = $result_item_name->fetch_assoc();
                $item_name = $item_details['name'];

                // جلب الخيارات الحالية لهذا الصنف
                $stmt_get_options = $conn->prepare("SELECT id, option_group_name, option_name, additional_price, is_available FROM menu_item_options WHERE menu_item_id = ? ORDER BY option_group_name, id");
                if ($stmt_get_options) {
                    $stmt_get_options->bind_param("i", $item_id);
                    $stmt_get_options->execute();
                    $result_options = $stmt_get_options->get_result();
                    while ($row = $result_options->fetch_assoc()) {
                        $item_options[] = $row;
                    }
                    $stmt_get_options->close();
                } else {
                    $error_message = "خطأ في جلب خيارات الصنف.";
                    error_log("SQL Error (get item options): " . $conn->error);
                }
            } else {
                $error_message = "الصنف غير موجود أو ليس لديك صلاحية لإدارة خياراته.";
            }
            $stmt_get_item->close();
        } else {
            $error_message = "فشل في التحقق من الصنف.";
            error_log("SQL Error (check item for options): " . $conn->error);
        }
    }
} else {
    $error_message = "لم يتم تحديد صنف لإدارة خياراته.";
}

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة خيارات الصنف: <?php echo htmlspecialchars($item_name); ?> - <?php echo $restaurant_name; ?></title>
    <style>
        /* يمكنك نسخ الأنماط من الصفحات السابقة أو استخدام ملف مشترك */
        body { font-family: sans-serif; direction: rtl; margin: 0; background-color: #f4f4f4; }
        .navbar { background-color: #333; padding: 15px 30px; color: white; display: flex; justify-content: space-between; align-items: center; }
        .navbar h1 { margin: 0; font-size: 1.2em; }
        .navbar a { color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; }
        .navbar a.active, .navbar a:hover { background-color: #555; }
        .container { padding: 20px; max-width: 900px; margin: 20px auto; background-color: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2, h3 { border-bottom: 2px solid #eee; padding-bottom: 10px; margin-top: 0; }
        h3 { margin-top: 20px; }
        table { width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 0.9em; }
        th, td { text-align: right; padding: 8px; border: 1px solid #ddd; }
        th { background-color: #f9f9f9; }
        .action-links a { margin-left: 8px; text-decoration: none; white-space: nowrap; }
        .action-links .edit { color: #007bff; }
        .action-links .delete { color: red; }
        .form-section { margin-top: 30px; padding-top: 20px; border-top: 2px solid #eee; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input[type="text"], input[type="number"], select {
            width: calc(100% - 22px); padding: 10px; margin-bottom: 15px;
            border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;
        }
        input[type="submit"] { background-color: #28a745; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        input[type="submit"]:hover { background-color: #218838; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; text-align: center; }
        .message.success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .message.error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .no-data { text-align: center; color: #777; padding: 20px; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #555; text-decoration: none; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <nav class="navbar">
        <h1><a href="dashboard.php">لوحة تحكم: <?php echo $restaurant_name; ?></a></h1>
        <div>
            <a href="manage_items.php" class="active">إدارة الأصناف</a>
            <a href="logout.php">تسجيل الخروج</a>
        </div>
    </nav>

    <div class="container">
        <h2>إدارة خيارات الصنف: <span style="color: #007bff;"><?php echo htmlspecialchars($item_name); ?></span></h2>
        <a href="manage_items.php" class="back-link">&laquo; العودة إلى قائمة الأصناف</a>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <p class="message error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php elseif ($item_id): // إذا كان معرّف الصنف صالحًا وتم جلب اسمه ?>
            <h3>الخيارات الحالية للصنف</h3>
            <?php if (!empty($item_options)): ?>
                <table>
                    <thead>
                        <tr>
                            <th>مجموعة الخيار</th>
                            <th>اسم الخيار</th>
                            <th>السعر الإضافي</th>
                            <th>الحالة</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($item_options as $option): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($option['option_group_name']); ?></td>
                            <td><?php echo htmlspecialchars($option['option_name']); ?></td>
                            <td><?php echo htmlspecialchars(number_format($option['additional_price'], 2)); ?></td>
                            <td><?php echo $option['is_available'] ? 'متوفر' : 'غير متوفر'; ?></td>
                            <td class="action-links">
                                <a href="edit_item_option.php?id=<?php echo $option['id']; ?>&item_id=<?php echo $item_id; ?>" class="edit">تعديل</a>
                                <a href="delete_item_option.php?id=<?php echo $option['id']; ?>&item_id=<?php echo $item_id; ?>" class="delete" onclick="return confirm('هل أنت متأكد من رغبتك في حذف هذا الخيار؟');">حذف</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-data">لا توجد خيارات مضافة لهذا الصنف حاليًا.</p>
            <?php endif; ?>

            <div class="form-section">
                <h3>إضافة خيار جديد للصنف "<?php echo htmlspecialchars($item_name); ?>"</h3>
                <form action="handle_add_item_option.php" method="POST">
                    <input type="hidden" name="menu_item_id" value="<?php echo htmlspecialchars($item_id); ?>">

                    <label for="option_group_name">اسم مجموعة الخيار (مثال: الحجم، الإضافات):</label>
                    <input type="text" id="option_group_name" name="option_group_name" required placeholder="الحجم">

                    <label for="option_name">اسم الخيار (مثال: صغير، جبنة إضافية):</label>
                    <input type="text" id="option_name" name="option_name" required placeholder="صغير">

                    <label for="additional_price">السعر الإضافي (اتركه 0 إذا كان بدون سعر إضافي):</label>
                    <input type="number" id="additional_price" name="additional_price" step="0.01" value="0.00" required>
                    
                    <label for="is_available">حالة الخيار:</label>
                    <select id="is_available" name="is_available">
                        <option value="1" selected>متوفر</option>
                        <option value="0">غير متوفر</option>
                    </select>

                    <input type="submit" name="add_item_option" value="إضافة الخيار">
                </form>
            </div>
        <?php endif; // نهاية التحقق من $item_id ?>
    </div>

</body>
</html>