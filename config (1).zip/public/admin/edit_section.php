<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$restaurant_name = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name']) : 'المطعم';

$section_id_to_edit = null;
$section_data = null;
$error_message = '';
$message = ''; // لرسائل النجاح أو الخطأ من المعالجة إذا تمت في نفس الصفحة
$message_type = '';

// التحقق من وجود معرّف القسم في الرابط
if (isset($_GET['id'])) {
    $section_id_to_edit = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

    if ($section_id_to_edit === false || $section_id_to_edit <= 0) {
        $error_message = "معرّف القسم غير صالح.";
    } else {
        // جلب بيانات القسم للتعديل والتأكد أنه يتبع للمطعم
        $stmt_get_section = $conn->prepare("SELECT id, name, display_order, is_visible FROM menu_sections WHERE id = ? AND restaurant_id = ?");
        if ($stmt_get_section) {
            $stmt_get_section->bind_param("ii", $section_id_to_edit, $restaurant_id);
            $stmt_get_section->execute();
            $result = $stmt_get_section->get_result();
            if ($result->num_rows == 1) {
                $section_data = $result->fetch_assoc();
            } else {
                $error_message = "القسم غير موجود أو ليس لديك صلاحية لتعديله.";
            }
            $stmt_get_section->close();
        } else {
            $error_message = "فشل في إعداد عملية جلب بيانات القسم.";
            error_log("SQL Error in edit_section (prepare get): " . $conn->error);
        }
    }
} else {
    $error_message = "لم يتم تحديد قسم للتعديل.";
}

// (سيتم إضافة كود معالجة التحديث هنا في الخطوة التالية إذا قررنا دمجها، أو في ملف منفصل)
// في هذا المثال، سنفترض أن المعالجة ستتم في ملف handle_edit_section.php

// إذا كان هناك رسالة قادمة من المعالجة (بعد التحديث)
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
    $message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : 'info';
}

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل قسم - <?php echo $restaurant_name; ?></title>
    <style>
        body { font-family: sans-serif; direction: rtl; margin: 0; background-color: #f4f4f4; }
        .navbar { background-color: #333; padding: 15px 30px; color: white; display: flex; justify-content: space-between; align-items: center; }
        .navbar h1 { margin: 0; font-size: 1.2em; }
        .navbar a { color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; }
        .navbar a.active, .navbar a:hover { background-color: #555; }
        .container { padding: 20px; max-width: 700px; margin: 20px auto; background-color: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { border-bottom: 2px solid #eee; padding-bottom: 10px; margin-top: 0; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input[type="text"], input[type="number"], select {
            width: calc(100% - 22px); padding: 10px; margin-bottom: 15px;
            border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;
        }
        input[type="submit"] { background-color: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        input[type="submit"]:hover { background-color: #0056b3; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; text-align: center; }
        .message.success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .message.error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #555; text-decoration: none; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <nav class="navbar">
        <h1><a href="dashboard.php">لوحة تحكم: <?php echo $restaurant_name; ?></a></h1>
        <div>
            <a href="manage_sections.php" class="active">إدارة الأقسام</a>
            <a href="logout.php">تسجيل الخروج</a>
        </div>
    </nav>

    <div class="container">
        <h2>تعديل قسم</h2>
        <a href="manage_sections.php" class="back-link">&laquo; العودة إلى قائمة الأقسام</a>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <p class="message error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php elseif ($section_data): ?>
            <form action="handle_edit_section.php" method="POST">
                <input type="hidden" name="section_id" value="<?php echo htmlspecialchars($section_data['id']); ?>">

                <label for="section_name">اسم القسم:</label>
                <input type="text" id="section_name" name="section_name" value="<?php echo htmlspecialchars($section_data['name']); ?>" required>

                <label for="display_order">ترتيب العرض:</label>
                <input type="number" id="display_order" name="display_order" value="<?php echo htmlspecialchars($section_data['display_order']); ?>" required>
                
                <label for="is_visible">الحالة:</label>
                <select id="is_visible" name="is_visible">
                    <option value="1" <?php if ($section_data['is_visible'] == 1) echo 'selected'; ?>>ظاهر</option>
                    <option value="0" <?php if ($section_data['is_visible'] == 0) echo 'selected'; ?>>مخفي</option>
                </select>

                <input type="submit" name="edit_section" value="حفظ التعديلات">
            </form>
        <?php endif; ?>
    </div>

</body>
</html>