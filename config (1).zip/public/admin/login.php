<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل دخول المطاعم</title>
    <style>
        body { font-family: sans-serif; direction: rtl; margin: 20px; background-color: #f4f4f4; }
        .container { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 400px; margin: 50px auto; }
        h2 { text-align: center; color: #333; }
        label { display: block; margin-bottom: 8px; color: #555; }
        input[type="email"], input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        input[type="submit"]:hover { background-color: #0056b3; }
        .error-message { color: red; margin-bottom: 15px; text-align: center; }
        .message { margin-top: 15px; text-align: center; }
        .message a { color: #007bff; text-decoration: none; }
        .message a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h2>تسجيل دخول المطاعم</h2>
        <?php
        // لعرض رسائل الخطأ القادمة من معالج تسجيل الدخول
        if (isset($_GET['error'])) {
            if ($_GET['error'] == '1') {
                echo '<p class="error-message">البريد الإلكتروني أو كلمة المرور غير صحيحة.</p>';
            } elseif ($_GET['error'] == '2') {
                echo '<p class="error-message">الرجاء إدخال البريد الإلكتروني وكلمة المرور.</p>';
            }
        }
        ?>
        <form action="handle_login.php" method="POST">
            <label for="email">البريد الإلكتروني:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">كلمة المرور:</label>
            <input type="password" id="password" name="password" required>

            <input type="submit" value="تسجيل الدخول">
        </form>
        <div class="message">
            <p>ليس لديك حساب؟ <a href="register.php">سجل الآن</a></p>
        </div>
    </div>
</body>
</html>