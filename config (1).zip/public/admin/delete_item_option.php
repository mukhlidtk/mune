<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    // إذا كان هذا ملف معالجة، فالأفضل عدم التوجيه لـ login.php مباشرة
    // بل التوجيه لصفحة سابقة مع رسالة خطأ، أو إيقاف التنفيذ.
    // بما أننا نحتاج item_id للعودة، سيكون التوجيه معقدًا بدون item_id صالح
    die("وصول غير مصرح به أو جلسة غير صالحة.");
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$message = '';
$message_type = '';
$item_id_for_redirect = null; // لتخزين item_id لإعادة التوجيه

// التحقق من وجود معرّف الخيار ومعرّف الصنف في الرابط
if (isset($_GET['id']) && isset($_GET['item_id'])) {
    $option_id_to_delete = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $item_id_for_redirect = filter_input(INPUT_GET, 'item_id', FILTER_VALIDATE_INT); // هذا هو menu_item_id

    if ($option_id_to_delete === false || $option_id_to_delete <= 0 || $item_id_for_redirect === false || $item_id_for_redirect <= 0) {
        $message = "المعرفات المطلوبة غير صالحة.";
        $message_type = "error";
    } else {
        // قبل الحذف، تحقق أن الصنف (item_id_for_redirect) يتبع لمطعم المستخدم الحالي
        // هذا يضمن أننا نحذف خيارًا من صنف يملكه المستخدم
        $stmt_check_item_owner = $conn->prepare(
            "SELECT mi.id 
             FROM menu_items mi
             JOIN menu_categories mc ON mi.menu_category_id = mc.id
             JOIN menu_sections ms ON mc.menu_section_id = ms.id
             WHERE mi.id = ? AND ms.restaurant_id = ?"
        );
        
        if ($stmt_check_item_owner) {
            $stmt_check_item_owner->bind_param("ii", $item_id_for_redirect, $restaurant_id);
            $stmt_check_item_owner->execute();
            $stmt_check_item_owner->store_result();

            if ($stmt_check_item_owner->num_rows == 1) {
                // الصنف يتبع للمطعم، الآن يمكن حذف الخيار
                $stmt_check_item_owner->close();

                // نحذف الخيار بناءً على id الخاص به والتأكد أنه يتبع لـ item_id الصحيح
                $stmt_delete = $conn->prepare("DELETE FROM menu_item_options WHERE id = ? AND menu_item_id = ?");
                if ($stmt_delete) {
                    $stmt_delete->bind_param("ii", $option_id_to_delete, $item_id_for_redirect);
                    if ($stmt_delete->execute()) {
                        if ($stmt_delete->affected_rows > 0) {
                            $message = "تم حذف الخيار بنجاح.";
                            $message_type = "success";
                        } else {
                            $message = "لم يتم العثور على الخيار المحدد أو أنه لا يتبع لهذا الصنف.";
                            $message_type = "error";
                        }
                    } else {
                        $message = "فشل في حذف الخيار. خطأ في التنفيذ.";
                        $message_type = "error";
                        error_log("SQL Error in delete_item_option (execute): " . $stmt_delete->error);
                    }
                    $stmt_delete->close();
                } else {
                    $message = "فشل في إعداد عملية حذف الخيار.";
                    $message_type = "error";
                    error_log("SQL Error in delete_item_option (prepare delete): " . $conn->error);
                }
            } else {
                // الصنف لا يتبع للمطعم أو غير موجود
                $message = "الصنف المرتبط بهذا الخيار غير موجود أو ليس لديك صلاحية عليه.";
                $message_type = "error";
                if ($stmt_check_item_owner) $stmt_check_item_owner->close();
            }
        } else {
            $message = "فشل في التحقق من ملكية الصنف.";
            $message_type = "error";
            error_log("SQL Error in delete_item_option (prepare check item owner): " . $conn->error);
        }
    }
} else {
    $message = "لم يتم تحديد خيار للحذف أو معرّف الصنف مفقود.";
    $message_type = "error";
}

// إغلاق اتصال قاعدة البيانات
if (isset($conn) && $conn instanceof mysqli) {
    $conn->close();
}

// إعادة التوجيه إلى صفحة إدارة خيارات الصنف مع رسالة
// إذا كان item_id_for_redirect غير صالح، نوجه لصفحة إدارة الأصناف الرئيسية
$redirect_url = "manage_items.php"; // افتراضي
if ($item_id_for_redirect !== null && $item_id_for_redirect > 0) {
    $redirect_url = "manage_item_options.php?item_id=" . $item_id_for_redirect;
}

header("Location: " . $redirect_url . "&message=" . urlencode($message) . "&message_type=" . urlencode($message_type));
exit();

?>