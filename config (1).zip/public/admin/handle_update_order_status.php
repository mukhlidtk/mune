<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: view_orders.php?message=unauthorized&message_type=error");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id_session = $_SESSION['restaurant_id']; // ID المطعم من الجلسة

// الحالات الممكنة للطلب (يجب أن تكون مطابقة لما هو في view_orders.php أو من مصدر مشترك)
$allowed_statuses = [
    'جديد',
    'قيد التجهيز',
    'جاهز للاستلام',
    'مكتمل',
    'ملغي'
];

// التحقق من أن الطلب هو POST ومن أن زر التحديث قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_status'])) {

    // الحصول على البيانات من النموذج
    $order_id = filter_input(INPUT_POST, 'order_id', FILTER_VALIDATE_INT);
    $new_status = trim($_POST['new_status']);

    // التحقق الأساسي من المدخلات
    if ($order_id === false || $order_id <= 0) {
        header("Location: view_orders.php?message=معرف الطلب غير صالح.&message_type=error");
        exit();
    }
    if (empty($new_status) || !in_array($new_status, $allowed_statuses)) {
        header("Location: view_orders.php?message=حالة الطلب الجديدة غير صالحة.&message_type=error");
        exit();
    }

    // إعداد استعلام SQL لتحديث حالة الطلب
    // مهم: التأكد أن التحديث يتم فقط للطلب الذي يتبع للمطعم المسجل دخوله (عبر restaurant_id)
    $stmt_update_status = $conn->prepare("UPDATE orders SET order_status = ? WHERE id = ? AND restaurant_id = ?");
    
    if ($stmt_update_status) {
        $stmt_update_status->bind_param("sii", $new_status, $order_id, $restaurant_id_session);

        if ($stmt_update_status->execute()) {
            // نجح التحديث
            if ($stmt_update_status->affected_rows > 0) {
                $message = "تم تحديث حالة الطلب رقم " . $order_id . " بنجاح إلى '" . htmlspecialchars($new_status) . "'.";
                $message_type = "success";
            } else {
                // لم يتم تحديث أي صفوف، قد يعني أن الحالة لم تتغير فعليًا، أو أن الطلب لا يتبع للمطعم (تم التحقق منه بالشرط)
                $message = "لم يتم إجراء أي تغيير على حالة الطلب، أو أن الطلب غير موجود ضمن صلاحياتك.";
                $message_type = "info"; 
            }
        } else {
            // فشل التحديث
            $message = "فشل في تحديث حالة الطلب. خطأ في التنفيذ.";
            $message_type = "error";
            error_log("SQL Error in handle_update_order_status (execute): " . $stmt_update_status->error);
        }
        $stmt_update_status->close();
    } else {
        // فشل في إعداد الاستعلام
        $message = "فشل في إعداد عملية تحديث حالة الطلب.";
        $message_type = "error";
        error_log("SQL Error in handle_update_order_status (prepare): " . $conn->error);
    }
    $conn->close();
} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر التحديث، يتم توجيه المستخدم
    $message = "طلب غير صالح.";
    $message_type = "error";
}

// إعادة التوجيه إلى صفحة عرض الطلبات مع رسالة
header("Location: view_orders.php?message=" . urlencode($message) . "&message_type=" . urlencode($message_type));
exit();
?>