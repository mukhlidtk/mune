<?php
// ابدأ الجلسة
session_start();

// 1. قم بإلغاء تعيين جميع متغيرات الجلسة
$_SESSION = array();

// 2. إذا كنت ترغب في تدمير الجلسة بالكامل، قم أيضًا بحذف ملف تعريف الارتباط الخاص بالجلسة.
// ملاحظة: هذا سيدمر الجلسة، وليس فقط بيانات الجلسة!
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 3. أخيرًا، قم بتدمير الجلسة.
session_destroy();

// 4. قم بتوجيه المستخدم إلى صفحة تسجيل الدخول
// يمكنك إضافة رسالة هنا إذا أردت، مثل ?status=logged_out
header("Location: login.php");
exit;
?>