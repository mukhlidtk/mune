<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: manage_sections.php?message=unauthorized&message_type=error");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];

// التحقق من أن الطلب هو POST ومن أن زر التعديل قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_section'])) {

    // الحصول على البيانات من النموذج وتنقيتها
    $section_id = filter_input(INPUT_POST, 'section_id', FILTER_VALIDATE_INT);
    $section_name = trim($_POST['section_name']);
    $display_order = filter_input(INPUT_POST, 'display_order', FILTER_VALIDATE_INT);
    $is_visible = filter_input(INPUT_POST, 'is_visible', FILTER_VALIDATE_INT);

    // التحقق الأساسي من المدخلات
    if ($section_id === false || $section_id <= 0) {
        header("Location: manage_sections.php?message=معرف القسم غير صالح للتحديث.&message_type=error");
        exit();
    }
    if (empty($section_name)) {
        // عادةً، نعيد التوجيه إلى صفحة التعديل نفسها مع رسالة خطأ والحفاظ على المعرف
        header("Location: edit_section.php?id=" . $section_id . "&message=اسم القسم مطلوب.&message_type=error");
        exit();
    }

    if ($display_order === false || $display_order < 0) {
        $display_order = 0;
    }

    if ($is_visible === null || !in_array($is_visible, [0, 1])) {
        $is_visible = 1;
    }

    // إعداد استعلام SQL لتحديث البيانات
    // تأكد من أن التحديث يتم فقط للقسم الذي يتبع للمطعم المسجل دخوله (عبر restaurant_id)
    $stmt_update_section = $conn->prepare("UPDATE menu_sections SET name = ?, display_order = ?, is_visible = ? WHERE id = ? AND restaurant_id = ?");
    
    if ($stmt_update_section) {
        $stmt_update_section->bind_param("siiii", $section_name, $display_order, $is_visible, $section_id, $restaurant_id);

        if ($stmt_update_section->execute()) {
            // نجح التحديث
            if ($stmt_update_section->affected_rows > 0) {
                $message = "تم تحديث القسم بنجاح.";
                $message_type = "success";
            } else {
                // لم يتم تحديث أي صفوف، قد يعني أن البيانات لم تتغير أو أن القسم لا يتبع للمطعم (تم التحقق منه بشكل غير مباشر)
                $message = "لم يتم إجراء أي تغييرات على القسم، أو أن القسم غير موجود ضمن صلاحياتك.";
                $message_type = "info"; // أو 'warning'
            }
            $stmt_update_section->close();
            $conn->close();
            header("Location: manage_sections.php?message=" . urlencode($message) . "&message_type=" . urlencode($message_type));
            exit();
        } else {
            // فشل التحديث
            error_log("SQL Error in handle_edit_section (execute): " . $stmt_update_section->error);
            $stmt_update_section->close();
            $conn->close();
            // إعادة التوجيه إلى صفحة التعديل نفسها مع رسالة خطأ والحفاظ على المعرف
            header("Location: edit_section.php?id=" . $section_id . "&message=فشل في تحديث القسم. خطأ في التنفيذ.&message_type=error");
            exit();
        }
    } else {
        // فشل في إعداد الاستعلام
        error_log("SQL Error in handle_edit_section (prepare): " . $conn->error);
        $conn->close();
        header("Location: edit_section.php?id=" . $section_id . "&message=فشل في إعداد عملية تحديث القسم.&message_type=error");
        exit();
    }

} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر التعديل، يتم توجيه المستخدم
    header("Location: manage_sections.php");
    exit();
}
?>