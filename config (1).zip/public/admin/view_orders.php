<?php
session_start();

// التحقق من تسجيل الدخول
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$current_restaurant_name_from_session = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name'] ?? 'المطعم') : 'المطعم';

// رسائل الحالة من عمليات التحديث
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
$message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

// جلب الطلبات الخاصة بالمطعم، الأحدث أولاً
$orders = [];
$stmt_get_orders = $conn->prepare(
    "SELECT o.id, o.customer_name, o.customer_car_type, o.total_amount, o.order_status, o.created_at, o.order_notes 
     FROM orders o
     WHERE o.restaurant_id = ? 
     ORDER BY o.created_at DESC"
);

if ($stmt_get_orders) {
    $stmt_get_orders->bind_param("i", $restaurant_id);
    $stmt_get_orders->execute();
    $result_orders = $stmt_get_orders->get_result();
    if ($result_orders->num_rows > 0) {
        while ($row = $result_orders->fetch_assoc()) {
            // جلب أصناف كل طلب
            $order_items_for_this_order = [];
            $stmt_get_items = $conn->prepare(
                "SELECT item_name, quantity, price_per_item, selected_options, sub_total 
                 FROM order_items 
                 WHERE order_id = ?"
            );
            if ($stmt_get_items) {
                $stmt_get_items->bind_param("i", $row['id']);
                $stmt_get_items->execute();
                $result_order_items = $stmt_get_items->get_result();
                while($item_row = $result_order_items->fetch_assoc()){
                    $order_items_for_this_order[] = $item_row;
                }
                $stmt_get_items->close();
            }
            $row['items'] = $order_items_for_this_order;
            $orders[] = $row;
        }
    }
    $stmt_get_orders->close();
} else {
    // خطأ في إعداد استعلام جلب الطلبات
    // لا تقم بتعيين $message هنا مباشرة إذا كانت الصفحة ستعرضها من GET parameter أولاً
    // يمكنك تسجيل الخطأ error_log("SQL Error (prepare get orders): " . $conn->error);
}
// $conn->close(); // أغلق الاتصال في نهاية السكربت أو عند عدم الحاجة إليه

// الحالات الممكنة للطلب (يمكن تعديلها حسب الحاجة)
$order_statuses = [
    'جديد' => 'جديد',
    'قيد التجهيز' => 'قيد التجهيز',
    'جاهز للاستلام' => 'جاهز للاستلام',
    'مكتمل' => 'مكتمل',
    'ملغي' => 'ملغي'
];

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>عرض الطلبات - <?php echo $current_restaurant_name_from_session; ?></title>
    <link rel="stylesheet" href="css/admin_styles.css"> <style>
        /* أنماط إضافية خاصة بهذه الصفحة إذا لزم الأمر */
        .order-items-details table { 
            width: 100%; /* تعديل ليتناسب مع colspan */
            margin: 0; /* إزالة الهامش إذا كان داخل td */
            border: none; /* إزالة الحدود الخارجية إذا كانت داخل td */
        }
        .order-items-details th { background-color: #e9ecef; color:#343a40; }
        .order-items-details td { border-bottom: 1px solid #f1f1f1; }
        .order-items-details tr:last-child td { border-bottom: none; }
        #new-order-page-alert {
            position: sticky;
            top: 60px; /* تحت الـ navbar */
            z-index: 999;
            opacity: 1;
            transition: opacity 0.5s ease-out;
        }
    </style>
</head>
<body>

    <nav class="navbar">
        <h1>لوحة تحكم: <?php echo $current_restaurant_name_from_session; ?></h1>
        <a href="logout.php">تسجيل الخروج</a>
    </nav>

    <div class="main-container">
        <aside class="sidebar">
            <h2>القائمة الرئيسية</h2>
            <ul>
                <li><a href="dashboard.php">لوحة التحكم الرئيسية</a></li>
                <li><a href="manage_sections.php">إدارة أقسام المنيو</a></li>
                <li><a href="manage_categories.php">إدارة تصنيفات المنيو</a></li>
                <li><a href="manage_items.php">إدارة أصناف المنيو</a></li>
                <li><a href="view_orders.php" class="active">عرض الطلبات</a></li>
            </ul>
        </aside>

        <main class="content-area">
            <div class="page-header">
                <h2>قائمة الطلبات الواردة</h2>
            </div>

            <div id="new-order-page-alert-container"></div>

            <?php if (!empty($message)): ?>
                <div class="message <?php echo $message_type; ?>"><?php echo htmlspecialchars($message); ?></div>
            <?php endif; ?>

            <?php if (!empty($orders)): ?>
                <table class="data-table orders-table">
                    <thead>
                        <tr>
                            <th>رقم الطلب</th>
                            <th>اسم الزبون</th>
                            <th>نوع السيارة</th>
                            <th>الإجمالي</th>
                            <th>ملاحظات الزبون</th>
                            <th>وقت الطلب</th>
                            <th>الحالة الحالية</th>
                            <th>تغيير الحالة</th>
                            <th>التفاصيل</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($orders as $order): ?>
                        <tr id="order-row-<?php echo $order['id']; ?>">
                            <td><?php echo $order['id']; ?></td>
                            <td><?php echo htmlspecialchars($order['customer_name']); ?></td>
                            <td><?php echo htmlspecialchars($order['customer_car_type']); ?></td>
                            <td><?php echo number_format($order['total_amount'], 2); ?> ر.س</td>
                            <td><?php echo !empty($order['order_notes']) ? nl2br(htmlspecialchars($order['order_notes'])) : '-'; ?></td>
                            <td><?php echo date('Y-m-d H:i', strtotime($order['created_at'])); ?></td>
                            <td id="status-<?php echo $order['id']; ?>"><?php echo htmlspecialchars($order['order_status']); ?></td>
                            <td>
                                <form action="handle_update_order_status.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="order_id" value="<?php echo $order['id']; ?>">
                                    <select name="new_status" class="status-select">
                                        <?php foreach ($order_statuses as $status_key => $status_value): ?>
                                            <option value="<?php echo htmlspecialchars($status_key); ?>" <?php if ($order['order_status'] == $status_key) echo 'selected'; ?>>
                                                <?php echo htmlspecialchars($status_value); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" name="update_status" class="update-status-btn">تحديث</button>
                                </form>
                            </td>
                            <td>
                                <a href="javascript:void(0);" class="details-toggle" onclick="toggleOrderDetails('details-<?php echo $order['id']; ?>', this)">عرض</a>
                            </td>
                        </tr>
                        <tr id="details-<?php echo $order['id']; ?>" style="display:none;" class="order-items-details">
                            <td colspan="9">
                                <?php if(!empty($order['items'])): ?>
                                <table style="width:100%;"> <thead>
                                        <tr>
                                            <th>الصنف</th>
                                            <th>الكمية</th>
                                            <th>سعر الوحدة</th>
                                            <th>الخيارات المختارة</th>
                                            <th>الإجمالي الفرعي</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach($order['items'] as $item_detail): ?>
                                        <tr>
                                            <td><?php echo htmlspecialchars($item_detail['item_name']); ?></td>
                                            <td><?php echo $item_detail['quantity']; ?></td>
                                            <td><?php echo number_format($item_detail['price_per_item'], 2); ?> ر.س</td>
                                            <td>
                                                <?php
                                                if (!empty($item_detail['selected_options'])) {
                                                    $options_array = json_decode($item_detail['selected_options'], true);
                                                    if (is_array($options_array)) {
                                                        $display_options = [];
                                                        foreach ($options_array as $opt) {
                                                            $display_options[] = htmlspecialchars($opt['group'] ?? '') . ": " . htmlspecialchars($opt['name'] ?? '') . (isset($opt['price']) && floatval($opt['price']) > 0 ? ' (+'.number_format(floatval($opt['price']),2).' ر.س)' : '');
                                                        }
                                                        echo implode('<br>', $display_options);
                                                    } else { echo '-'; }
                                                } else { echo '-'; }
                                                ?>
                                            </td>
                                            <td><?php echo number_format($item_detail['sub_total'], 2); ?> ر.س</td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                                <?php else: ?>
                                <p style="text-align:center; padding:10px;">لا توجد أصناف مفصلة لهذا الطلب.</p>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="no-data">لا توجد طلبات واردة حاليًا.</p>
            <?php endif; ?>
        </main>
    </div>
<script>
function toggleOrderDetails(rowId, linkElement) {
    var detailsRow = document.getElementById(rowId);
    if (detailsRow) {
        if (detailsRow.style.display === 'none') {
            detailsRow.style.display = 'table-row'; // أو 'block' إذا لم يكن داخل جدول
            linkElement.textContent = 'إخفاء';
        } else {
            detailsRow.style.display = 'none';
            linkElement.textContent = 'عرض';
        }
    }
}

document.addEventListener('DOMContentLoaded', function() {
    // طلب إذن الإشعارات من المتصفح عند تحميل الصفحة إذا لم يتم تحديده بعد
    if (window.Notification && Notification.permission !== "granted" && Notification.permission !== "denied") {
        Notification.requestPermission().then(permission => {
            if (permission === "granted") {
                console.log("Notification permission granted.");
            } else {
                console.log("Notification permission denied.");
            }
        });
    }

    let audioContext;
    let notificationSoundBuffer;
    // !! ضع مسار ملف صوتي (مثل .mp3 أو .wav) مناسب لديك هنا !!
    const soundFilePath = '../sounds/notification.mp3'; // مثال: مجلد sounds بجانب مجلد public

    // دالة لتحميل الصوت
    async function loadSound(url) {
        if (!window.AudioContext && !window.webkitAudioContext) {
            console.warn("Web Audio API not supported by this browser.");
            return;
        }
        if (!audioContext) {
            audioContext = new (window.AudioContext || window.webkitAudioContext)();
        }
        try {
            const response = await fetch(url);
            const arrayBuffer = await response.arrayBuffer();
            notificationSoundBuffer = await audioContext.decodeAudioData(arrayBuffer);
            console.log("Sound loaded successfully.");
        } catch (error) {
            console.error("Error loading sound:", error);
        }
    }
    loadSound(soundFilePath);

    // لتشغيل الصوت عند أول تفاعل من المستخدم (سياسة المتصفحات الحديثة)
    function initializeAudioContext() {
        if (audioContext && audioContext.state === 'suspended') {
            audioContext.resume().then(() => {
                console.log("AudioContext resumed successfully by user interaction.");
            }).catch(e => console.error("Error resuming AudioContext:", e));
        }
        // إزالة المستمع بعد أول نقرة
        document.body.removeEventListener('click', initializeAudioContext);
        document.body.removeEventListener('touchstart', initializeAudioContext);
    }
    document.body.addEventListener('click', initializeAudioContext, { once: true });
    document.body.addEventListener('touchstart', initializeAudioContext, { once: true });


    // دالة لتشغيل الصوت
    function playNotificationSound() {
        if (notificationSoundBuffer && audioContext && audioContext.state === 'running') {
            const source = audioContext.createBufferSource();
            source.buffer = notificationSoundBuffer;
            source.connect(audioContext.destination);
            source.start(0);
        } else {
            console.warn("Sound not played. Buffer:", notificationSoundBuffer, "AudioContext State:", audioContext ? audioContext.state : "N/A");
            // كحل بديل بسيط جدًا، لكنه غير موثوق به بسبب سياسات التشغيل التلقائي
            // const fallbackAudio = new Audio(soundFilePath);
            // fallbackAudio.play().catch(e => console.warn("Fallback audio play warning:", e));
        }
    }

    // التحقق من دعم المتصفح لـ EventSource
    if (typeof(EventSource) !== "undefined") {
        const eventSource = new EventSource('order_event_stream.php');
        console.log("Connecting to SSE...");

        eventSource.onopen = function() {
            console.log("SSE Connection opened.");
        };

        eventSource.addEventListener('new_order', function(event) {
            console.log("Raw SSE event data:", event.data);
            try {
                const eventData = JSON.parse(event.data);
                console.log("Parsed SSE event data:", eventData);

                playNotificationSound();

                const notificationTitle = "طلب جديد ورد!";
                const notificationBody = `ورد طلب جديد برقم: ${eventData.order_id}. اضغط هنا للمراجعة.`;
                const notificationIcon = '../images/logo_notification.png'; // !! ضع مسار أيقونة مناسبة هنا !!

                if (Notification.permission === "granted") {
                    new Notification(notificationTitle, { body: notificationBody, icon: notificationIcon, tag: 'newOrder-' + eventData.order_id });
                }

                const alertContainer = document.getElementById('new-order-page-alert-container');
                const existingAlert = document.getElementById('new-order-alert-' + eventData.order_id);
                if (existingAlert) { existingAlert.remove(); } // إزالة التنبيه القديم لنفس الطلب إذا كان موجودًا

                const alertDiv = document.createElement('div');
                alertDiv.id = 'new-order-alert-' + eventData.order_id;
                alertDiv.className = 'message success'; // استخدم نفس تنسيق الرسائل
                alertDiv.innerHTML = `<strong>تنبيه!</strong> ${notificationBody} <a href="javascript:window.location.reload();" style="text-decoration:underline; color:inherit;">تحديث القائمة</a>`;
                alertDiv.style.cursor = 'pointer';
                alertDiv.onclick = function() { window.location.reload(); };
                
                alertContainer.insertBefore(alertDiv, alertContainer.firstChild); // إضافة الإشعار الجديد في الأعلى

                // (اختياري) جعل الصف الجديد للطلب مميزًا أو إضافته ديناميكيًا
                // هذا الجزء يتطلب تعديلات أكثر تعقيدًا لإعادة بناء HTML للجدول
                const orderRow = document.getElementById('order-row-' + eventData.order_id);
                if(orderRow) { // إذا كان الطلب موجودًا بالفعل في القائمة (مثلاً بعد تحديث يدوي)
                    orderRow.style.backgroundColor = '#d4edda'; // تمييزه باللون الأخضر الفاتح
                    setTimeout(() => { orderRow.style.backgroundColor = ''; }, 15000);
                } else {
                    // إذا أردت إضافة الطلب ديناميكيًا، ستحتاج لكود JS لإنشاء صف جديد في الجدول هنا
                    // الآن، نكتفي بالتنبيه ورابط التحديث
                }


            } catch (e) {
                console.error("Error parsing SSE data:", e, "Raw data:", event.data);
            }
        });

        eventSource.onerror = function(err) {
            console.error("EventSource failed:", err);
            // يمكن إيقاف الاتصال وإعادة محاولة الاتصال بعد فترة
            if (eventSource.readyState == EventSource.CLOSED) {
                console.log("SSE connection was closed.");
            }
        };

    } else {
        console.warn("متصفحك لا يدعم Server-Sent Events. التنبيهات الفورية لن تعمل.");
        const alertContainer = document.getElementById('new-order-page-alert-container');
        if (alertContainer) {
            const noSseDiv = document.createElement('div');
            noSseDiv.className = 'message error';
            noSseDiv.textContent = 'تنبيه: متصفحك لا يدعم التحديثات الفورية للطلبات. يرجى تحديث الصفحة يدويًا لرؤية الطلبات الجديدة.';
            alertContainer.appendChild(noSseDiv);
        }
    }
});
</script>
</body>
</html>