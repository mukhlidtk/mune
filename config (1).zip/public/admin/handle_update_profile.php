<?php
session_start();

// Check if user is logged in and restaurant_id is available in session
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    // Redirect to login or show an error. For a handler, it's often better to stop.
    header("Location: dashboard.php?message=unauthorized_access&message_type=error");
    exit;
}

// Include database connection
require_once __DIR__ . '/../../config/database.php';

$restaurant_id_session = $_SESSION['restaurant_id'];
$message = '';
$message_type = '';

// Check if the form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {

    // Retrieve and sanitize input data
    $restaurant_name = trim($_POST['restaurant_name']);
    $email = trim($_POST['email']);
    $short_link_slug = trim(strtolower($_POST['short_link_slug']));
    $phone_number = trim($_POST['phone_number']);
    $logo_url = trim($_POST['logo_url']);

    // --- Basic Validation ---
    if (empty($restaurant_name) || empty($email) || empty($short_link_slug)) {
        $message = "اسم المطعم، البريد الإلكتروني، واسم الرابط القصير حقول إلزامية.";
        $message_type = "error";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $message = "صيغة البريد الإلكتروني غير صحيحة.";
        $message_type = "error";
    } elseif (!preg_match('/^[a-z0-9-]+$/', $short_link_slug)) {
        $message = "اسم الرابط القصير يجب أن يحتوي على أحرف إنجليزية صغيرة، أرقام، وشرطات فقط.";
        $message_type = "error";
    } elseif (!empty($logo_url) && !filter_var($logo_url, FILTER_VALIDATE_URL)) {
        $message = "رابط الشعار غير صالح. يجب أن يكون URL كامل.";
        $message_type = "error";
    } else {
        // --- Check for uniqueness of email and slug if they were changed ---
        $can_proceed_with_update = true;

        // Get current email and slug to see if they changed
        $stmt_current_data = $conn->prepare("SELECT email, short_link_slug FROM restaurants WHERE id = ?");
        if ($stmt_current_data) {
            $stmt_current_data->bind_param("i", $restaurant_id_session);
            $stmt_current_data->execute();
            $result_current_data = $stmt_current_data->get_result();
            $current_data = $result_current_data->fetch_assoc();
            $stmt_current_data->close();

            if ($current_data) {
                // Check if email changed and if the new one is already taken
                if ($email !== $current_data['email']) {
                    $stmt_check_email = $conn->prepare("SELECT id FROM restaurants WHERE email = ? AND id != ?");
                    if ($stmt_check_email) {
                        $stmt_check_email->bind_param("si", $email, $restaurant_id_session);
                        $stmt_check_email->execute();
                        $stmt_check_email->store_result();
                        if ($stmt_check_email->num_rows > 0) {
                            $message = "البريد الإلكتروني '" . htmlspecialchars($email) . "' مستخدم بالفعل من قبل مطعم آخر.";
                            $message_type = "error";
                            $can_proceed_with_update = false;
                        }
                        $stmt_check_email->close();
                    } else {
                         error_log("SQL Error (check email uniqueness prepare): " . $conn->error);
                         $message = "خطأ في التحقق من البريد الإلكتروني.";
                         $message_type = "error";
                         $can_proceed_with_update = false;
                    }
                }

                // Check if slug changed and if the new one is already taken (only if email check passed)
                if ($can_proceed_with_update && $short_link_slug !== $current_data['short_link_slug']) {
                    $stmt_check_slug = $conn->prepare("SELECT id FROM restaurants WHERE short_link_slug = ? AND id != ?");
                    if ($stmt_check_slug) {
                        $stmt_check_slug->bind_param("si", $short_link_slug, $restaurant_id_session);
                        $stmt_check_slug->execute();
                        $stmt_check_slug->store_result();
                        if ($stmt_check_slug->num_rows > 0) {
                            $message = "اسم الرابط القصير '" . htmlspecialchars($short_link_slug) . "' مستخدم بالفعل.";
                            $message_type = "error";
                            $can_proceed_with_update = false;
                        }
                        $stmt_check_slug->close();
                    } else {
                        error_log("SQL Error (check slug uniqueness prepare): " . $conn->error);
                        $message = "خطأ في التحقق من اسم الرابط القصير.";
                        $message_type = "error";
                        $can_proceed_with_update = false;
                    }
                }
            } else {
                $message = "لم يتم العثور على بيانات المطعم الحالية.";
                $message_type = "error";
                $can_proceed_with_update = false;
            }
        } else {
            error_log("SQL Error (get current data prepare): " . $conn->error);
            $message = "خطأ في جلب البيانات الحالية للمطعم.";
            $message_type = "error";
            $can_proceed_with_update = false;
        }


        // --- Proceed with update if all checks passed ---
        if ($can_proceed_with_update) {
            if (empty($logo_url)) { // Handle empty optional URL
                $logo_url = null;
            }
            if (empty($phone_number)) { // Handle empty optional phone
                $phone_number = null;
            }

            $stmt_update = $conn->prepare("UPDATE restaurants SET name = ?, email = ?, short_link_slug = ?, phone_number = ?, logo_url = ? WHERE id = ?");
            if ($stmt_update) {
                $stmt_update->bind_param("sssssi", $restaurant_name, $email, $short_link_slug, $phone_number, $logo_url, $restaurant_id_session);
                if ($stmt_update->execute()) {
                    if ($stmt_update->affected_rows > 0) {
                        $message = "تم تحديث بيانات المطعم بنجاح.";
                        $message_type = "success";
                        // Update session restaurant name if it changed
                        if ($_SESSION['restaurant_name'] !== $restaurant_name) {
                            $_SESSION['restaurant_name'] = $restaurant_name;
                        }
                    } else {
                        $message = "لم يتم إجراء أي تغييرات على البيانات.";
                        $message_type = "info";
                    }
                } else {
                    $message = "فشل في تحديث بيانات المطعم. خطأ في التنفيذ.";
                    $message_type = "error";
                    error_log("SQL Error (update profile execute): " . $stmt_update->error);
                }
                $stmt_update->close();
            } else {
                $message = "فشل في إعداد عملية تحديث بيانات المطعم.";
                $message_type = "error";
                error_log("SQL Error (update profile prepare): " . $conn->error);
            }
        }
    }
    $conn->close();
} else {
    // If not a POST request or form not submitted, redirect to dashboard
    // This case should ideally not be reached if accessed via the form.
    $message = "طلب غير صالح.";
    $message_type = "error";
}

// Redirect back to dashboard with message
header("Location: dashboard.php?message=" . urlencode($message) . "&message_type=" . urlencode($message_type));
exit();
?>