<?php
// ... (session_start وكل شيء قبله) ...

/* <-- ابدأ التعليق من هنا
$stmt_restaurant_details = $conn->prepare("SELECT name, email, phone_number, logo_url, short_link_slug FROM restaurants WHERE id = ?");
if ($stmt_restaurant_details) {
    // ... كل الكود داخل هذا الـ if ...
    $stmt_restaurant_details->close();
} else {
    // ...
}
*/ //  <-- انتهي من التعليق هنا

// $conn->close(); // علّق هذا أيضًا إذا كان الاتصال معلقًا بالكامل

// ... (بقية الكود HTML يمكن تركه مبدئيًا) ...
?>