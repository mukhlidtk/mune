<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: manage_items.php?message=unauthorized&message_type=error");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];

// التحقق من أن الطلب هو POST ومن أن زر الإضافة قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_item'])) {

    // الحصول على البيانات من النموذج
    $menu_category_id = filter_input(INPUT_POST, 'menu_category_id', FILTER_VALIDATE_INT);
    $item_name = trim($_POST['item_name']);
    $description = trim($_POST['description']); // الوصف اختياري، لذا لا مشكلة إذا كان فارغًا
    $price = filter_input(INPUT_POST, 'price', FILTER_VALIDATE_FLOAT);
    $image_url = trim($_POST['image_url']);
    $display_order = filter_input(INPUT_POST, 'display_order', FILTER_VALIDATE_INT);
    $is_available = filter_input(INPUT_POST, 'is_available', FILTER_VALIDATE_INT);

    // التحقق الأساسي من المدخلات الإلزامية
    if ($menu_category_id === false || $menu_category_id <= 0) {
        header("Location: manage_items.php?message=الرجاء اختيار تصنيف صالح.&message_type=error");
        exit();
    }
    if (empty($item_name)) {
        header("Location: manage_items.php?message=اسم الصنف مطلوب.&message_type=error");
        exit();
    }
    if ($price === false || $price < 0) { // السعر يجب أن يكون رقمًا موجبًا أو صفر
        header("Location: manage_items.php?message=السعر المدخل غير صالح.&message_type=error");
        exit();
    }

    // (اختياري ولكن جيد) التحقق من أن التصنيف المختار (menu_category_id) يتبع لمطعم المستخدم
    $stmt_check_category_owner = $conn->prepare(
        "SELECT mc.id 
         FROM menu_categories mc
         JOIN menu_sections ms ON mc.menu_section_id = ms.id
         WHERE mc.id = ? AND ms.restaurant_id = ?"
    );
    if ($stmt_check_category_owner) {
        $stmt_check_category_owner->bind_param("ii", $menu_category_id, $restaurant_id);
        $stmt_check_category_owner->execute();
        $stmt_check_category_owner->store_result();
        if ($stmt_check_category_owner->num_rows == 0) {
            // التصنيف لا يتبع للمطعم أو غير موجود
            $stmt_check_category_owner->close();
            header("Location: manage_items.php?message=التصنيف المختار غير صالح أو لا تملكه.&message_type=error");
            exit();
        }
        $stmt_check_category_owner->close();
    } else {
        error_log("SQL Error (check category ownership for add item): " . $conn->error);
        header("Location: manage_items.php?message=خطأ في التحقق من التصنيف.&message_type=error");
        exit();
    }

    // التحقق من صحة رابط الصورة (إذا تم إدخاله)
    if (!empty($image_url) && !filter_var($image_url, FILTER_VALIDATE_URL)) {
        header("Location: manage_items.php?message=رابط الصورة غير صالح.&message_type=error");
        exit();
    }
    // إذا كان رابط الصورة فارغًا، اجعله NULL ليتم تخزينه بشكل صحيح في قاعدة البيانات
    if (empty($image_url)) {
        $image_url = null;
    }
    // إذا كان الوصف فارغًا، اجعله NULL
    if (empty($description)) {
        $description = null;
    }


    if ($display_order === false || $display_order < 0) {
        $display_order = 0;
    }
    if ($is_available === null || !in_array($is_available, [0, 1])) {
        $is_available = 1;
    }

    // إعداد استعلام SQL لإدخال البيانات
    $stmt_insert_item = $conn->prepare(
        "INSERT INTO menu_items (menu_category_id, name, description, price, image_url, display_order, is_available) 
         VALUES (?, ?, ?, ?, ?, ?, ?)"
    );
    
    if ($stmt_insert_item) {
        // s = string, d = double (for price), i = integer
        $stmt_insert_item->bind_param("issdsii", 
            $menu_category_id, 
            $item_name, 
            $description, 
            $price, 
            $image_url, 
            $display_order, 
            $is_available
        );

        if ($stmt_insert_item->execute()) {
            // نجحت الإضافة
            $stmt_insert_item->close();
            $conn->close();
            header("Location: manage_items.php?message=تم إضافة الصنف بنجاح.&message_type=success");
            exit();
        } else {
            // فشلت الإضافة
            error_log("SQL Error in handle_add_item (execute): " . $stmt_insert_item->error);
            $stmt_insert_item->close();
            $conn->close();
            header("Location: manage_items.php?message=فشل في إضافة الصنف. خطأ في التنفيذ: " . urlencode($stmt_insert_item->error) . "&message_type=error");
            exit();
        }
    } else {
        // فشل في إعداد الاستعلام
        error_log("SQL Error in handle_add_item (prepare): " . $conn->error);
        $conn->close();
        header("Location: manage_items.php?message=فشل في إعداد عملية إضافة الصنف.&message_type=error");
        exit();
    }

} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر الإضافة، يتم توجيه المستخدم
    header("Location: manage_items.php");
    exit();
}
?>