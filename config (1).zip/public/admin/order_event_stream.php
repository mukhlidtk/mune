<?php
session_start(); // للوصول إلى restaurant_id من الجلسة

// التحقق من تسجيل الدخول وأن restaurant_id موجود
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("HTTP/1.1 401 Unauthorized");
    exit;
}

$restaurant_id = $_SESSION['restaurant_id'];

// إعدادات Server-Sent Events
header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('X-Accel-Buffering: no'); // مهم لـ Nginx

// مسار مجلد ملفات الإشعارات
$notification_dir = __DIR__ . '/../../notifications'; // مجلد notifications بجانب مجلد public
$notification_file_path = $notification_dir . '/restaurant_' . $restaurant_id . '.new_order';

// متغير لتتبع آخر وقت تعديل للملف أو لتجنب الإرسال المتكرر لنفس الحدث
$last_event_data_hash = null; 

// حلقة لا نهائية (تقريبًا) لمراقبة التغييرات
while (true) {
    if (file_exists($notification_file_path)) {
        $file_content = file_get_contents($notification_file_path);
        $current_data_hash = md5($file_content); // إنشاء hash لمحتوى الملف الحالي

        // تحقق إذا كان هذا حدثًا جديدًا (لم يتم إرساله من قبل في هذه الجلسة من SSE)
        if ($current_data_hash !== $last_event_data_hash) {
            $event_data = json_decode($file_content, true);
            if ($event_data && isset($event_data['order_id'])) {
                // إرسال الحدث للعميل
                echo "event: new_order\n"; // اسم الحدث
                echo "data: " . json_encode(['message' => 'طلب جديد ورد!', 'order_id' => $event_data['order_id'], 'time' => $event_data['time']]) . "\n\n";
                ob_flush(); // تأكد من إرسال البيانات فورًا
                flush();

                $last_event_data_hash = $current_data_hash; // تحديث الـ hash لآخر حدث تم إرساله

                // (اختياري) يمكن حذف ملف الإشعار بعد إرساله لمنع إرساله مرة أخرى
                // أو يمكن تعديل آلية المراقبة لتقرأ فقط "الجديد"
                // الآن، سنتركه ليتم الكتابة فوقه بالطلب التالي
                // unlink($notification_file_path); // إذا أردت حذفه
            }
        }
    }

    // انتظر قليلاً قبل التحقق مرة أخرى لتقليل الحمل على الخادم
    sleep(3); // تحقق كل 3 ثواني (يمكن تعديل هذه القيمة)

    // إذا انقطع الاتصال من العميل، يجب أن تتوقف الحلقة
    if (connection_aborted()) {
        break;
    }
}
?>