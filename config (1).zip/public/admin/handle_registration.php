<?php
// تضمين ملف الاتصال بقاعدة البيانات
// المسار قد يحتاج للتعديل بناءً على مكان هذا الملف بالنسبة لملف database.php
// إذا كان handle_registration.php في public/admin/ و database.php في config/
// المسار الصحيح سيكون: ../../config/database.php
require_once __DIR__ . '/../../config/database.php'; // __DIR__ يعطي المسار المطلق للمجلد الحالي

// بدء أو استئناف الجلسة (قد نحتاجها لاحقًا)
// session_start();

// التحقق من أن الطلب هو POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // الحصول على البيانات من النموذج وتنقيتها بشكل أساسي
    $restaurant_name = trim($_POST['restaurant_name']);
    $email = trim($_POST['email']);
    $password = $_POST['password']; // لا تقم بـ trim لكلمة المرور الآن
    $short_link_slug = trim(strtolower($_POST['short_link_slug'])); // تحويل إلى أحرف صغيرة
    $phone_number = trim($_POST['phone_number']);

    // التحقق الأساسي من المدخلات (يمكن إضافة المزيد من التحقق)
    if (empty($restaurant_name) || empty($email) || empty($password) || empty($short_link_slug)) {
        header("Location: register.php?status=error&message=empty_fields");
        exit();
    }

    // التحقق من صحة تنسيق الرابط القصير (أحرف إنجليزية صغيرة، أرقام، شرطات)
    if (!preg_match('/^[a-z0-9-]+$/', $short_link_slug)) {
        header("Location: register.php?status=invalid_slug");
        exit();
    }

    // التحقق من أن البريد الإلكتروني أو الرابط القصير غير مستخدمين بالفعل
    $stmt_check = $conn->prepare("SELECT id FROM restaurants WHERE email = ? OR short_link_slug = ?");
    $stmt_check->bind_param("ss", $email, $short_link_slug);
    $stmt_check->execute();
    $stmt_check->store_result();

    if ($stmt_check->num_rows > 0) {
        $stmt_check->close();
        header("Location: register.php?status=exists");
        exit();
    }
    $stmt_check->close();

    // تشفير كلمة المرور (مهم جداً!)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // إعداد استعلام SQL لإدخال البيانات (باستخدام Prepared Statements للحماية من SQL Injection)
    $stmt = $conn->prepare("INSERT INTO restaurants (name, email, password, short_link_slug, phone_number) VALUES (?, ?, ?, ?, ?)");
    
    // ربط المتغيرات بالاستعلام
    // s = string, i = integer, d = double, b = blob
    $stmt->bind_param("sssss", $restaurant_name, $email, $hashed_password, $short_link_slug, $phone_number);

    // تنفيذ الاستعلام
    if ($stmt->execute()) {
        // نجح التسجيل
        $stmt->close();
        $conn->close();
        header("Location: register.php?status=success"); // توجيه لصفحة التسجيل مع رسالة نجاح
        exit();
    } else {
        // فشل التسجيل
        error_log("SQL Error in handle_registration: " . $stmt->error); // تسجيل الخطأ
        $stmt->close();
        $conn->close();
        header("Location: register.php?status=error"); // توجيه لصفحة التسجيل مع رسالة خطأ
        exit();
    }

} else {
    // إذا لم يكن الطلب POST، يتم توجيه المستخدم لصفحة التسجيل
    header("Location: register.php");
    exit();
}
?>