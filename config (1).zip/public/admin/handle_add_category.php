<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: manage_categories.php?message=unauthorized&message_type=error");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];

// التحقق من أن الطلب هو POST ومن أن زر الإضافة قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_category'])) {

    // الحصول على البيانات من النموذج وتنقيتها
    $menu_section_id = filter_input(INPUT_POST, 'menu_section_id', FILTER_VALIDATE_INT);
    $category_name = trim($_POST['category_name']);
    $display_order = filter_input(INPUT_POST, 'display_order', FILTER_VALIDATE_INT);
    $is_visible = filter_input(INPUT_POST, 'is_visible', FILTER_VALIDATE_INT);

    // التحقق الأساسي من المدخلات
    if ($menu_section_id === false || $menu_section_id <= 0) {
        header("Location: manage_categories.php?message=الرجاء اختيار قسم صالح.&message_type=error");
        exit();
    }
    if (empty($category_name)) {
        header("Location: manage_categories.php?message=اسم التصنيف مطلوب.&message_type=error");
        exit();
    }

    // (اختياري ولكن جيد) التحقق من أن القسم المختار (menu_section_id) يتبع للمطعم الحالي
    $stmt_check_section = $conn->prepare("SELECT id FROM menu_sections WHERE id = ? AND restaurant_id = ?");
    if ($stmt_check_section) {
        $stmt_check_section->bind_param("ii", $menu_section_id, $restaurant_id);
        $stmt_check_section->execute();
        $stmt_check_section->store_result();
        if ($stmt_check_section->num_rows == 0) {
            // القسم لا يتبع للمطعم أو غير موجود
            $stmt_check_section->close();
            header("Location: manage_categories.php?message=القسم المختار غير صالح أو لا تملكه.&message_type=error");
            exit();
        }
        $stmt_check_section->close();
    } else {
        error_log("SQL Error (check section ownership): " . $conn->error);
        header("Location: manage_categories.php?message=خطأ في التحقق من القسم.&message_type=error");
        exit();
    }


    if ($display_order === false || $display_order < 0) {
        $display_order = 0;
    }
    if ($is_visible === null || !in_array($is_visible, [0, 1])) {
        $is_visible = 1;
    }

    // إعداد استعلام SQL لإدخال البيانات
    $stmt_insert_category = $conn->prepare("INSERT INTO menu_categories (menu_section_id, name, display_order, is_visible) VALUES (?, ?, ?, ?)");
    
    if ($stmt_insert_category) {
        $stmt_insert_category->bind_param("isii", $menu_section_id, $category_name, $display_order, $is_visible);

        if ($stmt_insert_category->execute()) {
            // نجحت الإضافة
            $stmt_insert_category->close();
            $conn->close();
            header("Location: manage_categories.php?message=تم إضافة التصنيف بنجاح.&message_type=success");
            exit();
        } else {
            // فشلت الإضافة
            error_log("SQL Error in handle_add_category (execute): " . $stmt_insert_category->error);
            $stmt_insert_category->close();
            $conn->close();
            header("Location: manage_categories.php?message=فشل في إضافة التصنيف. خطأ في التنفيذ.&message_type=error");
            exit();
        }
    } else {
        // فشل في إعداد الاستعلام
        error_log("SQL Error in handle_add_category (prepare): " . $conn->error);
        $conn->close();
        header("Location: manage_categories.php?message=فشل في إعداد عملية إضافة التصنيف.&message_type=error");
        exit();
    }

} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر الإضافة، يتم توجيه المستخدم
    header("Location: manage_categories.php");
    exit();
}
?>