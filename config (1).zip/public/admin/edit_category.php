<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$restaurant_name = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name']) : 'المطعم';

$category_id_to_edit = null;
$category_data = null;
$sections_for_dropdown = [];
$error_message = '';
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
$message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

// جلب الأقسام الخاصة بالمطعم (لاختيار القسم عند تعديل التصنيف)
$stmt_get_sections_dropdown = $conn->prepare("SELECT id, name FROM menu_sections WHERE restaurant_id = ? ORDER BY display_order ASC, name ASC");
if ($stmt_get_sections_dropdown) {
    $stmt_get_sections_dropdown->bind_param("i", $restaurant_id);
    $stmt_get_sections_dropdown->execute();
    $result_sections_dropdown = $stmt_get_sections_dropdown->get_result();
    if ($result_sections_dropdown->num_rows > 0) {
        while ($row = $result_sections_dropdown->fetch_assoc()) {
            $sections_for_dropdown[] = $row;
        }
    }
    $stmt_get_sections_dropdown->close();
} else {
    $error_message = "خطأ في جلب قائمة الأقسام.";
    error_log("SQL Error (get sections for dropdown): " . $conn->error);
}


// التحقق من وجود معرّف التصنيف في الرابط وجلب بياناته
if (isset($_GET['id']) && empty($error_message)) { // لا تستمر إذا كان هناك خطأ سابق
    $category_id_to_edit = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

    if ($category_id_to_edit === false || $category_id_to_edit <= 0) {
        $error_message = "معرّف التصنيف غير صالح.";
    } else {
        // جلب بيانات التصنيف للتعديل والتأكد أنه يتبع للمطعم (عبر القسم)
        $stmt_get_category = $conn->prepare(
            "SELECT mc.id, mc.name, mc.display_order, mc.is_visible, mc.menu_section_id 
             FROM menu_categories mc
             JOIN menu_sections ms ON mc.menu_section_id = ms.id
             WHERE mc.id = ? AND ms.restaurant_id = ?"
        );
        if ($stmt_get_category) {
            $stmt_get_category->bind_param("ii", $category_id_to_edit, $restaurant_id);
            $stmt_get_category->execute();
            $result = $stmt_get_category->get_result();
            if ($result->num_rows == 1) {
                $category_data = $result->fetch_assoc();
            } else {
                $error_message = "التصنيف غير موجود أو ليس لديك صلاحية لتعديله.";
            }
            $stmt_get_category->close();
        } else {
            $error_message = "فشل في إعداد عملية جلب بيانات التصنيف.";
            error_log("SQL Error in edit_category (prepare get): " . $conn->error);
        }
    }
} elseif (empty($error_message)) { // إذا لم يكن هناك ID ولكن لا يوجد خطأ سابق
    $error_message = "لم يتم تحديد تصنيف للتعديل.";
}

// لا نغلق $conn هنا حتى الآن
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل تصنيف - <?php echo $restaurant_name; ?></title>
    <style>
        /* يمكنك نسخ الأنماط من manage_categories.php أو استخدام ملف مشترك */
        body { font-family: sans-serif; direction: rtl; margin: 0; background-color: #f4f4f4; }
        .navbar { background-color: #333; padding: 15px 30px; color: white; display: flex; justify-content: space-between; align-items: center; }
        .navbar h1 { margin: 0; font-size: 1.2em; }
        .navbar a { color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; }
        .navbar a.active, .navbar a:hover { background-color: #555; }
        .container { padding: 20px; max-width: 700px; margin: 20px auto; background-color: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { border-bottom: 2px solid #eee; padding-bottom: 10px; margin-top: 0; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input[type="text"], input[type="number"], select {
            width: calc(100% - 22px); padding: 10px; margin-bottom: 15px;
            border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;
        }
        input[type="submit"] { background-color: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        input[type="submit"]:hover { background-color: #0056b3; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; text-align: center; }
        .message.success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .message.error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #555; text-decoration: none; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <nav class="navbar">
        <h1><a href="dashboard.php">لوحة تحكم: <?php echo $restaurant_name; ?></a></h1>
        <div>
            <a href="manage_sections.php">إدارة الأقسام</a>
            <a href="manage_categories.php" class="active">إدارة التصنيفات</a>
            <a href="logout.php">تسجيل الخروج</a>
        </div>
    </nav>

    <div class="container">
        <h2>تعديل تصنيف</h2>
        <a href="manage_categories.php" class="back-link">&laquo; العودة إلى قائمة التصنيفات</a>

        <?php if (!empty($message)): ?>
            <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <p class="message error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php elseif (empty($sections_for_dropdown) && $category_data) : // إذا كان هناك تصنيف ولكن لا أقسام للاختيار منها (حالة نادرة) ?>
            <p class="message error">لا توجد أقسام متاحة لربط التصنيف بها. يرجى <a href="manage_sections.php">إضافة قسم</a> أولاً.</p>
        <?php elseif ($category_data && !empty($sections_for_dropdown)): ?>
            <form action="handle_edit_category.php" method="POST">
                <input type="hidden" name="category_id" value="<?php echo htmlspecialchars($category_data['id']); ?>">

                <label for="menu_section_id">اختر القسم:</label>
                <select id="menu_section_id" name="menu_section_id" required>
                    <option value="">-- اختر قسم --</option>
                    <?php foreach ($sections_for_dropdown as $section): ?>
                        <option value="<?php echo $section['id']; ?>" <?php if ($category_data['menu_section_id'] == $section['id']) echo 'selected'; ?>>
                            <?php echo htmlspecialchars($section['name']); ?>
                        </option>
                    <?php endforeach; ?>
                </select>

                <label for="category_name">اسم التصنيف:</label>
                <input type="text" id="category_name" name="category_name" value="<?php echo htmlspecialchars($category_data['name']); ?>" required>

                <label for="display_order">ترتيب العرض:</label>
                <input type="number" id="display_order" name="display_order" value="<?php echo htmlspecialchars($category_data['display_order']); ?>" required>
                
                <label for="is_visible">الحالة:</label>
                <select id="is_visible" name="is_visible">
                    <option value="1" <?php if ($category_data['is_visible'] == 1) echo 'selected'; ?>>ظاهر</option>
                    <option value="0" <?php if ($category_data['is_visible'] == 0) echo 'selected'; ?>>مخفي</option>
                </select>

                <input type="submit" name="edit_category" value="حفظ التعديلات">
            </form>
        <?php elseif (!$category_data && empty($error_message)) : // إذا لم يتم العثور على التصنيف ولم يكن هناك خطأ سابق محدد ?>
             <p class="message error">لم يتم العثور على التصنيف المحدد.</p>
        <?php endif; ?>
    </div>

</body>
</html>