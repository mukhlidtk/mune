<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: manage_categories.php?message=unauthorized&message_type=error");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];

// التحقق من أن الطلب هو POST ومن أن زر التعديل قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_category'])) {

    // الحصول على البيانات من النموذج وتنقيتها
    $category_id = filter_input(INPUT_POST, 'category_id', FILTER_VALIDATE_INT);
    $menu_section_id = filter_input(INPUT_POST, 'menu_section_id', FILTER_VALIDATE_INT);
    $category_name = trim($_POST['category_name']);
    $display_order = filter_input(INPUT_POST, 'display_order', FILTER_VALIDATE_INT);
    $is_visible = filter_input(INPUT_POST, 'is_visible', FILTER_VALIDATE_INT);

    // التحقق الأساسي من المدخلات
    if ($category_id === false || $category_id <= 0) {
        header("Location: manage_categories.php?message=معرف التصنيف غير صالح للتحديث.&message_type=error");
        exit();
    }
    if ($menu_section_id === false || $menu_section_id <= 0) {
        header("Location: edit_category.php?id=" . $category_id . "&message=الرجاء اختيار قسم صالح.&message_type=error");
        exit();
    }
    if (empty($category_name)) {
        header("Location: edit_category.php?id=" . $category_id . "&message=اسم التصنيف مطلوب.&message_type=error");
        exit();
    }

    // التحقق من أن القسم المختار (menu_section_id) يتبع للمطعم الحالي (مهم جدًا للأمان)
    $stmt_check_section_owner = $conn->prepare("SELECT id FROM menu_sections WHERE id = ? AND restaurant_id = ?");
    if ($stmt_check_section_owner) {
        $stmt_check_section_owner->bind_param("ii", $menu_section_id, $restaurant_id);
        $stmt_check_section_owner->execute();
        $stmt_check_section_owner->store_result();
        if ($stmt_check_section_owner->num_rows == 0) {
            // القسم لا يتبع للمطعم أو غير موجود
            $stmt_check_section_owner->close();
            header("Location: edit_category.php?id=" . $category_id . "&message=القسم المختار غير صالح أو لا تملكه.&message_type=error");
            exit();
        }
        $stmt_check_section_owner->close();
    } else {
        error_log("SQL Error (check section ownership for edit category): " . $conn->error);
        header("Location: edit_category.php?id=" . $category_id . "&message=خطأ في التحقق من ملكية القسم.&message_type=error");
        exit();
    }


    if ($display_order === false || $display_order < 0) {
        $display_order = 0;
    }
    if ($is_visible === null || !in_array($is_visible, [0, 1])) {
        $is_visible = 1;
    }

    // إعداد استعلام SQL لتحديث البيانات
    // نتحقق من ملكية التصنيف بشكل غير مباشر من خلال التأكد أن صفحة edit_category.php لم تعرض إلا التصنيفات المملوكة
    // والآن تحققنا أن القسم الجديد الذي سيتم ربط التصنيف به هو أيضاً مملوك.
    $stmt_update_category = $conn->prepare("UPDATE menu_categories SET name = ?, display_order = ?, is_visible = ?, menu_section_id = ? WHERE id = ?");
    
    if ($stmt_update_category) {
        // لاحظ أننا لا نحتاج لـ restaurant_id مباشرة في جملة UPDATE هنا،
        // لأننا نعتمد على أن edit_category.php عرض فقط التصنيفات المملوكة،
        // وتحققنا الآن أن menu_section_id الجديد مملوك أيضًا.
        // إذا أردت طبقة أمان إضافية في جملة UPDATE نفسها، سيتطلب الأمر استعلامًا أكثر تعقيدًا
        // أو التأكد أن category_id نفسه يتبع للمطعم (عادة هذا يتم قبل عرض صفحة التعديل).
        $stmt_update_category->bind_param("siiii", $category_name, $display_order, $is_visible, $menu_section_id, $category_id);

        if ($stmt_update_category->execute()) {
            // نجح التحديث
            if ($stmt_update_category->affected_rows > 0) {
                $message = "تم تحديث التصنيف بنجاح.";
                $message_type = "success";
            } else {
                $message = "لم يتم إجراء أي تغييرات على التصنيف.";
                $message_type = "info";
            }
            $stmt_update_category->close();
            $conn->close();
            header("Location: manage_categories.php?message=" . urlencode($message) . "&message_type=" . urlencode($message_type));
            exit();
        } else {
            // فشل التحديث
            error_log("SQL Error in handle_edit_category (execute): " . $stmt_update_category->error);
            $stmt_update_category->close();
            $conn->close();
            header("Location: edit_category.php?id=" . $category_id . "&message=فشل في تحديث التصنيف. خطأ في التنفيذ.&message_type=error");
            exit();
        }
    } else {
        // فشل في إعداد الاستعلام
        error_log("SQL Error in handle_edit_category (prepare): " . $conn->error);
        $conn->close();
        header("Location: edit_category.php?id=" . $category_id . "&message=فشل في إعداد عملية تحديث التصنيف.&message_type=error");
        exit();
    }

} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر التعديل، يتم توجيه المستخدم
    header("Location: manage_categories.php");
    exit();
}
?>