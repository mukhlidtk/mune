<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    // إذا كان هذا ملف معالجة، فالأفضل عدم التوجيه لـ login.php مباشرة
    // بل التوجيه لصفحة سابقة مع رسالة خطأ، أو إيقاف التنفيذ.
    // سنفترض أننا سنعود لصفحة إدارة الخيارات مع رسالة.
    // header("Location: manage_items.php?message=unauthorized&message_type=error"); // مسار أفضل
    die("وصول غير مصرح به."); // أو أوقف التنفيذ
    // exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];

// التحقق من أن الطلب هو POST ومن أن زر الإضافة قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_item_option'])) {

    // الحصول على البيانات من النموذج
    $menu_item_id = filter_input(INPUT_POST, 'menu_item_id', FILTER_VALIDATE_INT);
    $option_group_name = trim($_POST['option_group_name']);
    $option_name = trim($_POST['option_name']);
    $additional_price = filter_input(INPUT_POST, 'additional_price', FILTER_VALIDATE_FLOAT);
    $is_available = filter_input(INPUT_POST, 'is_available', FILTER_VALIDATE_INT);

    // التحقق الأساسي من المدخلات الإلزامية
    if ($menu_item_id === false || $menu_item_id <= 0) {
        header("Location: manage_items.php?message=معرف الصنف غير صالح لإضافة خيار.&message_type=error"); // توجيه لصفحة الأصناف الرئيسية
        exit();
    }
    if (empty($option_group_name) || empty($option_name)) {
        header("Location: manage_item_options.php?item_id=" . $menu_item_id . "&message=اسم مجموعة الخيار واسم الخيار مطلوبان.&message_type=error");
        exit();
    }
    if ($additional_price === false || $additional_price < 0) { // السعر يجب أن يكون رقمًا موجبًا أو صفر
        $additional_price = 0.00; // قيمة افتراضية إذا كان الإدخال غير صالح
    }
     if ($is_available === null || !in_array($is_available, [0, 1])) {
        $is_available = 1; // قيمة افتراضية
    }

    // التحقق من أن الصنف (menu_item_id) يتبع لمطعم المستخدم الحالي (أمان مهم)
    $stmt_check_item_owner = $conn->prepare(
        "SELECT mi.id 
         FROM menu_items mi
         JOIN menu_categories mc ON mi.menu_category_id = mc.id
         JOIN menu_sections ms ON mc.menu_section_id = ms.id
         WHERE mi.id = ? AND ms.restaurant_id = ?"
    );
    if ($stmt_check_item_owner) {
        $stmt_check_item_owner->bind_param("ii", $menu_item_id, $restaurant_id);
        $stmt_check_item_owner->execute();
        $stmt_check_item_owner->store_result();
        if ($stmt_check_item_owner->num_rows == 0) {
            // الصنف لا يتبع للمطعم أو غير موجود
            $stmt_check_item_owner->close();
            header("Location: manage_items.php?message=الصنف المحدد غير صالح أو لا تملكه.&message_type=error");
            exit();
        }
        $stmt_check_item_owner->close();
    } else {
        error_log("SQL Error (check item ownership for add option): " . $conn->error);
        header("Location: manage_item_options.php?item_id=" . $menu_item_id . "&message=خطأ في التحقق من الصنف.&message_type=error");
        exit();
    }

    // إعداد استعلام SQL لإدخال البيانات
    $stmt_insert_option = $conn->prepare(
        "INSERT INTO menu_item_options (menu_item_id, option_group_name, option_name, additional_price, is_available) 
         VALUES (?, ?, ?, ?, ?)"
    );
    
    if ($stmt_insert_option) {
        $stmt_insert_option->bind_param("issdi", 
            $menu_item_id, 
            $option_group_name, 
            $option_name, 
            $additional_price,
            $is_available
        );

        if ($stmt_insert_option->execute()) {
            // نجحت الإضافة
            $stmt_insert_option->close();
            $conn->close();
            header("Location: manage_item_options.php?item_id=" . $menu_item_id . "&message=تم إضافة الخيار بنجاح.&message_type=success");
            exit();
        } else {
            // فشلت الإضافة
            error_log("SQL Error in handle_add_item_option (execute): " . $stmt_insert_option->error);
            $stmt_insert_option->close();
            $conn->close();
            header("Location: manage_item_options.php?item_id=" . $menu_item_id . "&message=فشل في إضافة الخيار. خطأ في التنفيذ: " . urlencode($stmt_insert_option->error) . "&message_type=error");
            exit();
        }
    } else {
        // فشل في إعداد الاستعلام
        error_log("SQL Error in handle_add_item_option (prepare): " . $conn->error);
        $conn->close();
        header("Location: manage_item_options.php?item_id=" . $menu_item_id . "&message=فشل في إعداد عملية إضافة الخيار.&message_type=error");
        exit();
    }

} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر الإضافة، يتم توجيه المستخدم
    // توجيه لصفحة إدارة الأصناف الرئيسية كإجراء افتراضي إذا لم يكن الطلب صحيحًا
    header("Location: manage_items.php");
    exit();
}
?>