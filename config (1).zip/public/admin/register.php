<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تسجيل مطعم جديد</title>
    <style>
        body { font-family: sans-serif; direction: rtl; margin: 20px; background-color: #f4f4f4; }
        .container { background-color: #fff; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); max-width: 500px; margin: auto; }
        h2 { text-align: center; color: #333; }
        label { display: block; margin-bottom: 8px; color: #555; }
        input[type="text"], input[type="email"], input[type="password"] {
            width: calc(100% - 22px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        input[type="submit"] {
            background-color: #28a745;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        input[type="submit"]:hover { background-color: #218838; }
        .error-message { color: red; margin-bottom: 15px; text-align: center; }
        .success-message { color: green; margin-bottom: 15px; text-align: center; }
    </style>
</head>
<body>
    <div class="container">
        <h2>تسجيل مطعم جديد</h2>
        <?php
        // لعرض رسائل النجاح أو الخطأ القادمة من معالج التسجيل
        if (isset($_GET['status'])) {
            if ($_GET['status'] == 'success') {
                echo '<p class="success-message">تم تسجيل المطعم بنجاح!</p>';
            } elseif ($_GET['status'] == 'error') {
                echo '<p class="error-message">فشل تسجيل المطعم. الرجاء المحاولة مرة أخرى.</p>';
            } elseif ($_GET['status'] == 'exists') {
                echo '<p class="error-message">البريد الإلكتروني أو اسم الرابط القصير مستخدم بالفعل.</p>';
            } elseif ($_GET['status'] == 'invalid_slug') {
                echo '<p class="error-message">اسم الرابط القصير يجب أن يحتوي على أحرف إنجليزية صغيرة وأرقام وشرطات فقط.</p>';
            }
        }
        ?>
        <form action="handle_registration.php" method="POST">
            <label for="name">اسم المطعم:</label>
            <input type="text" id="name" name="restaurant_name" required>

            <label for="email">البريد الإلكتروني (لتسجيل الدخول):</label>
            <input type="email" id="email" name="email" required>

            <label for="password">كلمة المرور:</label>
            <input type="password" id="password" name="password" required minlength="8">

            <label for="short_link_slug">اسم الرابط القصير (بالإنجليزية، بدون مسافات، مثال: my-cool-restaurant):</label>
            <input type="text" id="short_link_slug" name="short_link_slug" required pattern="[a-z0-9-]+" title="أحرف إنجليزية صغيرة، أرقام، وشرطات فقط">
            
            <label for="phone_number">رقم الهاتف (اختياري):</label>
            <input type="text" id="phone_number" name="phone_number">

            <input type="submit" value="تسجيل المطعم">
        </form>
    </div>
</body>
</html>