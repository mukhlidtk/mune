<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php"); // أو أظهر رسالة خطأ مناسبة
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$message = '';
$message_type = '';

// التحقق من وجود معرّف القسم في الرابط (GET request)
if (isset($_GET['id'])) {
    $section_id_to_delete = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

    if ($section_id_to_delete === false || $section_id_to_delete <= 0) {
        $message = "معرّف القسم غير صالح.";
        $message_type = "error";
    } else {
        // قبل الحذف، تحقق أن هذا القسم يتبع للمطعم المسجل دخوله (زيادة أمان)
        $stmt_check = $conn->prepare("SELECT id FROM menu_sections WHERE id = ? AND restaurant_id = ?");
        if ($stmt_check) {
            $stmt_check->bind_param("ii", $section_id_to_delete, $restaurant_id);
            $stmt_check->execute();
            $stmt_check->store_result();

            if ($stmt_check->num_rows == 1) {
                // القسم موجود ويتبع للمطعم، يمكن حذفه
                $stmt_check->close(); // أغلق الاستعلام الأول قبل فتح استعلام جديد

                $stmt_delete = $conn->prepare("DELETE FROM menu_sections WHERE id = ? AND restaurant_id = ?");
                if ($stmt_delete) {
                    $stmt_delete->bind_param("ii", $section_id_to_delete, $restaurant_id);
                    if ($stmt_delete->execute()) {
                        $message = "تم حذف القسم بنجاح.";
                        $message_type = "success";
                    } else {
                        $message = "فشل في حذف القسم. خطأ في التنفيذ.";
                        $message_type = "error";
                        error_log("SQL Error in delete_section (execute): " . $stmt_delete->error);
                    }
                    $stmt_delete->close();
                } else {
                    $message = "فشل في إعداد عملية حذف القسم.";
                    $message_type = "error";
                    error_log("SQL Error in delete_section (prepare delete): " . $conn->error);
                }
            } else {
                // القسم لا يتبع للمطعم أو غير موجود
                $message = "القسم غير موجود أو ليس لديك صلاحية لحذفه.";
                $message_type = "error";
                if ($stmt_check) $stmt_check->close();
            }
        } else {
            $message = "فشل في التحقق من صلاحية حذف القسم.";
            $message_type = "error";
            error_log("SQL Error in delete_section (prepare check): " . $conn->error);
        }
    }
} else {
    $message = "لم يتم تحديد قسم للحذف.";
    $message_type = "error";
}

// إغلاق اتصال قاعدة البيانات
if (isset($conn) && $conn instanceof mysqli) {
    $conn->close();
}

// إعادة التوجيه إلى صفحة إدارة الأقسام مع رسالة
header("Location: manage_sections.php?message=" . urlencode($message) . "&message_type=" . urlencode($message_type));
exit();

?>