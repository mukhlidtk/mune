<?php
session_start();

if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$current_restaurant_name_from_session = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name'] ?? 'المطعم') : 'المطعم';

$item_id_to_edit = null;
$item_data = null;
$categories_for_dropdown = [];
$error_message = '';
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
$message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

$sql_get_categories_dropdown = "
    SELECT mc.id, mc.name AS category_name, ms.name AS section_name 
    FROM menu_categories mc
    JOIN menu_sections ms ON mc.menu_section_id = ms.id
    WHERE ms.restaurant_id = ? 
    ORDER BY ms.display_order ASC, ms.name ASC, mc.display_order ASC, mc.name ASC";
$stmt_get_categories_dropdown = $conn->prepare($sql_get_categories_dropdown);

if ($stmt_get_categories_dropdown) {
    $stmt_get_categories_dropdown->bind_param("i", $restaurant_id);
    $stmt_get_categories_dropdown->execute();
    $result_categories_dropdown = $stmt_get_categories_dropdown->get_result();
    if ($result_categories_dropdown->num_rows > 0) {
        while ($row = $result_categories_dropdown->fetch_assoc()) {
            $categories_for_dropdown[] = $row;
        }
    }
    $stmt_get_categories_dropdown->close();
} else {
    $error_message = "خطأ في جلب قائمة التصنيفات.";
    error_log("SQL Error (get categories for dropdown - edit item): " . $conn->error);
}

if (isset($_GET['id']) && empty($error_message)) {
    $item_id_to_edit = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    if ($item_id_to_edit === false || $item_id_to_edit <= 0) {
        $error_message = "معرّف الصنف غير صالح.";
    } else {
        $stmt_get_item = $conn->prepare(
            "SELECT mi.id, mi.name, mi.description, mi.price, mi.image_url, mi.display_order, mi.is_available, mi.menu_category_id 
             FROM menu_items mi
             JOIN menu_categories mc ON mi.menu_category_id = mc.id
             JOIN menu_sections ms ON mc.menu_section_id = ms.id
             WHERE mi.id = ? AND ms.restaurant_id = ?"
        );
        if ($stmt_get_item) {
            $stmt_get_item->bind_param("ii", $item_id_to_edit, $restaurant_id);
            $stmt_get_item->execute();
            $result = $stmt_get_item->get_result();
            if ($result->num_rows == 1) {
                $item_data = $result->fetch_assoc();
            } else {
                $error_message = "الصنف غير موجود أو ليس لديك صلاحية لتعديله.";
            }
            $stmt_get_item->close();
        } else {
            $error_message = "فشل في إعداد عملية جلب بيانات الصنف.";
            error_log("SQL Error in edit_item (prepare get item): " . $conn->error);
        }
    }
} elseif (empty($error_message)) {
    $error_message = "لم يتم تحديد صنف للتعديل.";
}
// $conn->close(); // لا تغلق الاتصال هنا إذا كنت ستستخدمه لاحقًا في الصفحة
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل صنف - <?php echo $current_restaurant_name_from_session; ?></title>
    <link rel="stylesheet" href="css/admin_styles.css">
</head>
<body>
    <nav class="navbar">
        <h1>لوحة تحكم: <?php echo $current_restaurant_name_from_session; ?></h1>
        <a href="logout.php">تسجيل الخروج</a>
    </nav>
    <div class="main-container">
        <aside class="sidebar">
            <h2>القائمة الرئيسية</h2>
            <ul>
                <li><a href="dashboard.php">لوحة التحكم الرئيسية</a></li>
                <li><a href="manage_sections.php">إدارة أقسام المنيو</a></li>
                <li><a href="manage_categories.php">إدارة تصنيفات المنيو</a></li>
                <li><a href="manage_items.php" class="active">إدارة أصناف المنيو</a></li>
                <li><a href="view_orders.php">عرض الطلبات</a></li>
            </ul>
        </aside>
        <main class="content-area">
            <div class="page-header">
                <h2>تعديل صنف</h2>
            </div>
            <a href="manage_items.php" class="btn-secondary" style="margin-bottom:20px;">&laquo; العودة إلى قائمة الأصناف</a>

            <?php if (!empty($message)): ?>
                <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
                <div class="message error"><?php echo htmlspecialchars($error_message); ?></div>
            <?php elseif (empty($categories_for_dropdown) && $item_data) : ?>
                <div class="message error">لا توجد تصنيفات متاحة لربط الصنف بها. يرجى <a href="manage_categories.php">إضافة تصنيف</a> أولاً.</div>
            <?php elseif ($item_data && !empty($categories_for_dropdown)): ?>
                <div class="form-section">
                    <form action="handle_edit_item.php" method="POST">
                        <input type="hidden" name="item_id" value="<?php echo htmlspecialchars($item_data['id']); ?>">

                        <label for="menu_category_id">اختر التصنيف (القسم):</label>
                        <select id="menu_category_id" name="menu_category_id" required>
                            <option value="">-- اختر تصنيف --</option>
                            <?php foreach ($categories_for_dropdown as $category): ?>
                                <option value="<?php echo $category['id']; ?>" <?php if ($item_data['menu_category_id'] == $category['id']) echo 'selected'; ?>>
                                    <?php echo htmlspecialchars($category['section_name'] . ' > ' . $category['category_name']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>

                        <label for="item_name">اسم الصنف:</label>
                        <input type="text" id="item_name" name="item_name" value="<?php echo htmlspecialchars($item_data['name'] ?? ''); ?>" required>

                        <label for="description">وصف الصنف (اختياري):</label>
                        <textarea id="description" name="description"><?php echo htmlspecialchars($item_data['description'] ?? ''); // <<-- FIX APPLIED HERE ?></textarea>

                        <label for="price">السعر:</label>
                        <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo htmlspecialchars($item_data['price'] ?? '0.00'); ?>" required>
                        
                        <label for="image_url">رابط صورة الصنف (اختياري):</label>
                        <input type="url" id="image_url" name="image_url" placeholder="https://example.com/image.jpg" value="<?php echo htmlspecialchars($item_data['image_url'] ?? ''); // <<-- FIX APPLIED HERE ?>">

                        <label for="display_order">ترتيب العرض:</label>
                        <input type="number" id="display_order" name="display_order" value="<?php echo htmlspecialchars($item_data['display_order'] ?? '0'); ?>" min="0" required>
                        
                        <label for="is_available">الحالة:</label>
                        <select id="is_available" name="is_available">
                            <option value="1" <?php if (($item_data['is_available'] ?? 1) == 1) echo 'selected'; ?>>متوفر</option>
                            <option value="0" <?php if (($item_data['is_available'] ?? 1) == 0) echo 'selected'; ?>>غير متوفر</option>
                        </select>

                        <input type="submit" name="edit_item" value="حفظ التعديلات">
                    </form>
                </div>
            <?php elseif (!$item_data && empty($error_message)) : ?>
                 <div class="message error">لم يتم العثور على الصنف المحدد.</div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>