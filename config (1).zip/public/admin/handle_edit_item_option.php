<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    // هذا ملف معالجة، توجيه إلى صفحة عامة أو إيقاف التنفيذ
    // سنفترض العودة إلى صفحة الأصناف الرئيسية كإجراء أمان عام
    header("Location: manage_items.php?message=unauthorized&message_type=error");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];

// التحقق من أن الطلب هو POST ومن أن زر التعديل قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_item_option'])) {

    // الحصول على البيانات من النموذج
    $option_id = filter_input(INPUT_POST, 'option_id', FILTER_VALIDATE_INT);
    $menu_item_id = filter_input(INPUT_POST, 'menu_item_id', FILTER_VALIDATE_INT); // مهم للسياق والتحقق
    $option_group_name = trim($_POST['option_group_name']);
    $option_name = trim($_POST['option_name']);
    $additional_price = filter_input(INPUT_POST, 'additional_price', FILTER_VALIDATE_FLOAT);
    $is_available = filter_input(INPUT_POST, 'is_available', FILTER_VALIDATE_INT);

    // التحقق الأساسي من المدخلات
    if ($option_id === false || $option_id <= 0 || $menu_item_id === false || $menu_item_id <= 0) {
        header("Location: manage_items.php?message=معرفات الخيار أو الصنف غير صالحة للتحديث.&message_type=error");
        exit();
    }
    if (empty($option_group_name) || empty($option_name)) {
        header("Location: edit_item_option.php?id=" . $option_id . "&item_id=" . $menu_item_id . "&message=اسم مجموعة الخيار واسم الخيار مطلوبان.&message_type=error");
        exit();
    }
    if ($additional_price === false || $additional_price < 0) {
        $additional_price = 0.00;
    }
    if ($is_available === null || !in_array($is_available, [0, 1])) {
        $is_available = 1;
    }

    // التحقق من أن الصنف (menu_item_id) الذي يتبعه هذا الخيار يتبع لمطعم المستخدم الحالي (أمان مهم)
    $stmt_check_item_owner = $conn->prepare(
        "SELECT mi.id 
         FROM menu_items mi
         JOIN menu_categories mc ON mi.menu_category_id = mc.id
         JOIN menu_sections ms ON mc.menu_section_id = ms.id
         WHERE mi.id = ? AND ms.restaurant_id = ?"
    );
    if ($stmt_check_item_owner) {
        $stmt_check_item_owner->bind_param("ii", $menu_item_id, $restaurant_id);
        $stmt_check_item_owner->execute();
        $stmt_check_item_owner->store_result();
        if ($stmt_check_item_owner->num_rows == 0) {
            // الصنف لا يتبع للمطعم أو غير موجود
            $stmt_check_item_owner->close();
            // نوجه لصفحة إدارة الأصناف الرئيسية لأن سياق الصنف نفسه غير صالح
            header("Location: manage_items.php?message=الصنف المرتبط بهذا الخيار غير صالح أو لا تملكه.&message_type=error");
            exit();
        }
        $stmt_check_item_owner->close();
    } else {
        error_log("SQL Error (check item ownership for edit option): " . $conn->error);
        header("Location: edit_item_option.php?id=" . $option_id . "&item_id=" . $menu_item_id . "&message=خطأ في التحقق من ملكية الصنف.&message_type=error");
        exit();
    }

    // إعداد استعلام SQL لتحديث بيانات الخيار
    // نستخدم menu_item_id في جملة WHERE للتأكد أننا نعدل الخيار الصحيح التابع للصنف الصحيح
    $stmt_update_option = $conn->prepare(
        "UPDATE menu_item_options 
         SET option_group_name = ?, option_name = ?, additional_price = ?, is_available = ?
         WHERE id = ? AND menu_item_id = ?"
    );
    
    if ($stmt_update_option) {
        $stmt_update_option->bind_param("ssdiii", 
            $option_group_name, 
            $option_name, 
            $additional_price, 
            $is_available,
            $option_id,
            $menu_item_id // للتأكيد الإضافي
        );

        if ($stmt_update_option->execute()) {
            // نجح التحديث
            if ($stmt_update_option->affected_rows > 0) {
                $message = "تم تحديث الخيار بنجاح.";
                $message_type = "success";
            } else {
                $message = "لم يتم إجراء أي تغييرات على الخيار.";
                $message_type = "info"; 
            }
            $stmt_update_option->close();
            $conn->close();
            header("Location: manage_item_options.php?item_id=" . $menu_item_id . "&message=" . urlencode($message) . "&message_type=" . urlencode($message_type));
            exit();
        } else {
            // فشل التحديث
            error_log("SQL Error in handle_edit_item_option (execute): " . $stmt_update_option->error);
            $stmt_update_option->close();
            $conn->close();
            header("Location: edit_item_option.php?id=" . $option_id . "&item_id=" . $menu_item_id . "&message=فشل في تحديث الخيار. خطأ في التنفيذ: " . urlencode($stmt_update_option->error) . "&message_type=error");
            exit();
        }
    } else {
        // فشل في إعداد الاستعلام
        error_log("SQL Error in handle_edit_item_option (prepare): " . $conn->error);
        $conn->close();
        header("Location: edit_item_option.php?id=" . $option_id . "&item_id=" . $menu_item_id . "&message=فشل في إعداد عملية تحديث الخيار.&message_type=error");
        exit();
    }

} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر التعديل، يتم توجيه المستخدم
    header("Location: manage_items.php"); // توجيه عام لصفحة الأصناف
    exit();
}
?>