<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    // إذا لم يكن مسجلاً، قم بتوجيهه نظريًا إلى صفحة تسجيل الدخول
    // ولكن بما أن هذا ملف معالجة، قد يكون من الأفضل إيقاف التنفيذ أو إرجاع خطأ
    // لتجنب المشاكل، سنوجهه إلى صفحة إدارة الأقسام مع رسالة خطأ عامة.
    header("Location: manage_sections.php?message=unauthorized&message_type=error");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];

// التحقق من أن الطلب هو POST ومن أن زر الإضافة قد تم ضغطه
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_section'])) {

    // الحصول على البيانات من النموذج وتنقيتها
    $section_name = trim($_POST['section_name']);
    $display_order = filter_input(INPUT_POST, 'display_order', FILTER_VALIDATE_INT);
    $is_visible = filter_input(INPUT_POST, 'is_visible', FILTER_VALIDATE_INT); // 0 or 1

    // التحقق الأساسي من المدخلات
    if (empty($section_name)) {
        // إعادة التوجيه مع رسالة خطأ
        header("Location: manage_sections.php?message=اسم القسم مطلوب.&message_type=error");
        exit();
    }

    if ($display_order === false || $display_order < 0) { // false إذا لم يكن رقمًا صحيحًا
        $display_order = 0; // قيمة افتراضية إذا كان الإدخال غير صالح
    }

    if ($is_visible === null || !in_array($is_visible, [0, 1])) { // null إذا لم يكن 0 أو 1
        $is_visible = 1; // قيمة افتراضية إذا كان الإدخال غير صالح
    }

    // إعداد استعلام SQL لإدخال البيانات
    $stmt_insert_section = $conn->prepare("INSERT INTO menu_sections (restaurant_id, name, display_order, is_visible) VALUES (?, ?, ?, ?)");
    
    if ($stmt_insert_section) {
        $stmt_insert_section->bind_param("isii", $restaurant_id, $section_name, $display_order, $is_visible);

        if ($stmt_insert_section->execute()) {
            // نجحت الإضافة
            $stmt_insert_section->close();
            $conn->close();
            header("Location: manage_sections.php?message=تم إضافة القسم بنجاح.&message_type=success");
            exit();
        } else {
            // فشلت الإضافة
            error_log("SQL Error in handle_add_section (execute): " . $stmt_insert_section->error);
            $stmt_insert_section->close();
            $conn->close();
            header("Location: manage_sections.php?message=فشل في إضافة القسم. خطأ في التنفيذ.&message_type=error");
            exit();
        }
    } else {
        // فشل في إعداد الاستعلام
        error_log("SQL Error in handle_add_section (prepare): " . $conn->error);
        $conn->close();
        header("Location: manage_sections.php?message=فشل في إعداد عملية إضافة القسم.&message_type=error");
        exit();
    }

} else {
    // إذا لم يكن الطلب POST أو لم يتم ضغط زر الإضافة، يتم توجيه المستخدم
    header("Location: manage_sections.php");
    exit();
}
?>