<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);

echo "Attempting database connection...<br>";

// استخدم نفس معلومات الاتصال من ملف config/database.php
$db_host = "localhost"; // أو قيمة DB_HOST لديك
$db_user = "sabio_minu";   // أو قيمة DB_USER لديك
$db_pass = "Aa@05662212"; 
$db_name = "sabio_minu";   // أو قيمة DB_NAME لديك

$conn_test = new mysqli($db_host, $db_user, $db_pass, $db_name);

if ($conn_test->connect_error) {
    echo "Connection Failed: " . $conn_test->connect_error . "<br>";
} else {
    echo "Database Connection Successful!<br>";

    // جرب استعلامًا بسيطًا جدًا
    $result = $conn_test->query("SELECT 1");
    if ($result) {
        echo "Simple query successful.<br>";
    } else {
        echo "Simple query failed: " . $conn_test->error . "<br>";
    }
    $conn_test->close();
}
echo "Test script finished.<br>";
?>