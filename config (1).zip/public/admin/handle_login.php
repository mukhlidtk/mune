<?php
// ابدأ الجلسة دائمًا في بداية الملفات التي تحتاج إلى استخدام متغيرات الجلسة
session_start();

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php'; // تأكد من صحة هذا المسار

// التحقق من أن الطلب هو POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // الحصول على البيانات من النموذج
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    // التحقق من أن الحقول ليست فارغة
    if (empty($email) || empty($password)) {
        header("Location: login.php?error=2"); // خطأ: الحقول فارغة
        exit();
    }

    // إعداد استعلام SQL لجلب المستخدم بناءً على البريد الإلكتروني
    $stmt = $conn->prepare("SELECT id, name, password, is_active FROM restaurants WHERE email = ? LIMIT 1");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        // تم العثور على المستخدم، قم بجلب بياناته
        $restaurant = $result->fetch_assoc();

        // التحقق من كلمة المرور باستخدام password_verify()
        if (password_verify($password, $restaurant['password'])) {
            // كلمة المرور صحيحة
            
            // التحقق إذا كان الحساب نشطًا
            if ($restaurant['is_active']) {
                // تسجيل الدخول ناجح، قم بتخزين بيانات المطعم في الجلسة
                $_SESSION['restaurant_id'] = $restaurant['id'];
                $_SESSION['restaurant_name'] = $restaurant['name'];
                $_SESSION['logged_in'] = true;

                // إغلاق الاتصال بالداتا بيز والـ statement
                $stmt->close();
                $conn->close();

                // توجيه المستخدم إلى لوحة التحكم (سننشئ هذه الصفحة لاحقًا)
                header("Location: dashboard.php");
                exit();
            } else {
                // الحساب غير نشط
                header("Location: login.php?error=3"); // يمكنك إضافة رسالة خطأ مخصصة للحسابات غير النشطة
                exit();
            }

        } else {
            // كلمة المرور غير صحيحة
            header("Location: login.php?error=1");
            exit();
        }
    } else {
        // لم يتم العثور على مستخدم بهذا البريد الإلكتروني
        header("Location: login.php?error=1");
        exit();
    }

    // إغلاق الـ statement إذا لم يتم إغلاقه مسبقًا
    if (isset($stmt) && $stmt instanceof mysqli_stmt) {
        $stmt->close();
    }
    // إغلاق الاتصال بالداتا بيز إذا لم يتم إغلاقه مسبقًا
    if (isset($conn) && $conn instanceof mysqli) {
        $conn->close();
    }

} else {
    // إذا لم يكن الطلب POST، يتم توجيه المستخدم لصفحة تسجيل الدخول
    header("Location: login.php");
    exit();
}
?>