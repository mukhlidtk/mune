<?php
session_start();

// التحقق من تسجيل الدخول ومن وجود معرّف المطعم في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php';

$restaurant_id = $_SESSION['restaurant_id'];
$restaurant_name = isset($_SESSION['restaurant_name']) ? htmlspecialchars($_SESSION['restaurant_name']) : 'المطعم';

$option_id_to_edit = null;
$item_id_context = null; // معرّف الصنف الأب للسياق وإعادة التوجيه
$option_data = null;
$item_name_context = ''; // اسم الصنف الأب للعرض
$error_message = '';
$message = isset($_GET['message']) ? htmlspecialchars($_GET['message']) : '';
$message_type = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

// التحقق من وجود معرّف الخيار ومعرّف الصنف في الرابط
if (isset($_GET['id']) && isset($_GET['item_id'])) {
    $option_id_to_edit = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
    $item_id_context = filter_input(INPUT_GET, 'item_id', FILTER_VALIDATE_INT);

    if ($option_id_to_edit === false || $option_id_to_edit <= 0 || $item_id_context === false || $item_id_context <= 0) {
        $error_message = "المعرفات المطلوبة غير صالحة.";
    } else {
        // أولاً، تحقق من أن الصنف الأب (item_id_context) يتبع للمطعم الحالي واجلب اسمه
        $stmt_check_item_owner = $conn->prepare(
            "SELECT mi.name 
             FROM menu_items mi
             JOIN menu_categories mc ON mi.menu_category_id = mc.id
             JOIN menu_sections ms ON mc.menu_section_id = ms.id
             WHERE mi.id = ? AND ms.restaurant_id = ?"
        );
        if ($stmt_check_item_owner) {
            $stmt_check_item_owner->bind_param("ii", $item_id_context, $restaurant_id);
            $stmt_check_item_owner->execute();
            $result_item_check = $stmt_check_item_owner->get_result();
            if ($result_item_check->num_rows == 1) {
                $item_parent_details = $result_item_check->fetch_assoc();
                $item_name_context = $item_parent_details['name'];
                $stmt_check_item_owner->close();

                // الآن، اجلب بيانات الخيار المحدد وتأكد أنه يتبع للصنف الأب الصحيح
                $stmt_get_option = $conn->prepare("SELECT * FROM menu_item_options WHERE id = ? AND menu_item_id = ?");
                if ($stmt_get_option) {
                    $stmt_get_option->bind_param("ii", $option_id_to_edit, $item_id_context);
                    $stmt_get_option->execute();
                    $result_option = $stmt_get_option->get_result();
                    if ($result_option->num_rows == 1) {
                        $option_data = $result_option->fetch_assoc();
                    } else {
                        $error_message = "الخيار غير موجود أو لا يتبع للصنف المحدد.";
                    }
                    $stmt_get_option->close();
                } else {
                    $error_message = "فشل في إعداد عملية جلب بيانات الخيار.";
                    error_log("SQL Error in edit_item_option (prepare get option): " . $conn->error);
                }
            } else {
                // الصنف الأب لا يتبع للمطعم أو غير موجود
                $error_message = "الصنف المرتبط بهذا الخيار غير صالح أو لا تملكه.";
                if ($stmt_check_item_owner) $stmt_check_item_owner->close();
            }
        } else {
            $error_message = "فشل في التحقق من ملكية الصنف الأب.";
            error_log("SQL Error in edit_item_option (prepare check item owner): " . $conn->error);
        }
    }
} else {
    $error_message = "لم يتم تحديد خيار للتعديل أو معرّف الصنف الأب مفقود.";
}

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تعديل خيار الصنف <?php echo htmlspecialchars($item_name_context); ?> - <?php echo $restaurant_name; ?></title>
    <style>
        /* يمكنك نسخ الأنماط من الصفحات السابقة أو استخدام ملف مشترك */
        body { font-family: sans-serif; direction: rtl; margin: 0; background-color: #f4f4f4; }
        .navbar { background-color: #333; padding: 15px 30px; color: white; display: flex; justify-content: space-between; align-items: center; }
        .navbar h1 { margin: 0; font-size: 1.2em; }
        .navbar a { color: white; text-decoration: none; padding: 8px 15px; border-radius: 4px; }
        .navbar a.active, .navbar a:hover { background-color: #555; }
        .container { padding: 20px; max-width: 700px; margin: 20px auto; background-color: #fff; border-radius: 8px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h2 { border-bottom: 2px solid #eee; padding-bottom: 10px; margin-top: 0; }
        label { display: block; margin-bottom: 8px; font-weight: bold; }
        input[type="text"], input[type="number"], select {
            width: calc(100% - 22px); padding: 10px; margin-bottom: 15px;
            border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box;
        }
        input[type="submit"] { background-color: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; font-size: 16px; }
        input[type="submit"]:hover { background-color: #0056b3; }
        .message { padding: 10px; margin-bottom: 15px; border-radius: 4px; text-align: center; }
        .message.success { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .message.error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .back-link { display: inline-block; margin-bottom: 20px; color: #555; text-decoration: none; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>

    <nav class="navbar">
        <h1><a href="dashboard.php">لوحة تحكم: <?php echo $restaurant_name; ?></a></h1>
        <div>
            <a href="manage_item_options.php?item_id=<?php echo htmlspecialchars($item_id_context); ?>" class="active">إدارة خيارات الصنف</a>
            <a href="logout.php">تسجيل الخروج</a>
        </div>
    </nav>

    <div class="container">
        <h2>تعديل خيار للصنف: <span style="color: #007bff;"><?php echo htmlspecialchars($item_name_context); ?></span></h2>
        <?php if ($item_id_context): ?>
        <a href="manage_item_options.php?item_id=<?php echo htmlspecialchars($item_id_context); ?>" class="back-link">&laquo; العودة إلى خيارات الصنف</a>
        <?php else: ?>
        <a href="manage_items.php" class="back-link">&laquo; العودة إلى قائمة الأصناف</a>
        <?php endif; ?>


        <?php if (!empty($message)): ?>
            <div class="message <?php echo $message_type; ?>"><?php echo $message; ?></div>
        <?php endif; ?>

        <?php if (!empty($error_message)): ?>
            <p class="message error"><?php echo htmlspecialchars($error_message); ?></p>
        <?php elseif ($option_data): ?>
            <form action="handle_edit_item_option.php" method="POST">
                <input type="hidden" name="option_id" value="<?php echo htmlspecialchars($option_data['id']); ?>">
                <input type="hidden" name="menu_item_id" value="<?php echo htmlspecialchars($option_data['menu_item_id']); ?>"> 
                
                <label for="option_group_name">اسم مجموعة الخيار:</label>
                <input type="text" id="option_group_name" name="option_group_name" value="<?php echo htmlspecialchars($option_data['option_group_name']); ?>" required placeholder="الحجم">

                <label for="option_name">اسم الخيار:</label>
                <input type="text" id="option_name" name="option_name" value="<?php echo htmlspecialchars($option_data['option_name']); ?>" required placeholder="صغير">

                <label for="additional_price">السعر الإضافي:</label>
                <input type="number" id="additional_price" name="additional_price" step="0.01" value="<?php echo htmlspecialchars($option_data['additional_price']); ?>" required>
                
                <label for="is_available">حالة الخيار:</label>
                <select id="is_available" name="is_available">
                    <option value="1" <?php if ($option_data['is_available'] == 1) echo 'selected'; ?>>متوفر</option>
                    <option value="0" <?php if ($option_data['is_available'] == 0) echo 'selected'; ?>>غير متوفر</option>
                </select>

                <input type="submit" name="edit_item_option" value="حفظ التعديلات">
            </form>
        <?php elseif (empty($error_message)) : // لم يتم العثور على بيانات الخيار ولكن لا يوجد خطأ محدد ?>
             <p class="message error">لم يتم العثور على بيانات الخيار المحدد.</p>
        <?php endif; ?>
    </div>

</body>
</html>