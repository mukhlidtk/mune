<?php
// -----------------------------------------------------------------------------
// لإظهار أخطاء PHP مباشرة على الصفحة أثناء التطوير فقط (مهم جداً!)
// في بيئة الإنتاج (الموقع المباشر)، يجب تعطيل هذا وتوجيه الأخطاء إلى ملف سجل.
// لإلغاء تفعيل عرض الأخطاء، اجعل السطرين التاليين تعليقًا أو احذفهما.
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// -----------------------------------------------------------------------------

session_start();

// التحقق مما إذا كان المستخدم قد سجل دخوله وأن restaurant_id موجود في الجلسة
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true || !isset($_SESSION['restaurant_id'])) {
    header("Location: login.php");
    exit;
}

// تضمين ملف الاتصال بقاعدة البيانات
require_once __DIR__ . '/../../config/database.php'; // تأكد أن هذا المسار صحيح

$restaurant_id_session = (int)$_SESSION['restaurant_id']; 

// قيم افتراضية لبيانات المطعم - مهم تهيئتها كـ string لتجنب null مع htmlspecialchars
$current_restaurant_name = 'المطعم'; 
$current_email = '';
$current_phone = '';
$current_logo_url = '';
$current_slug = '';
$db_fetch_error_message = ''; // لتخزين أي خطأ في جلب البيانات من قاعدة البيانات

// التحقق من صلاحية الاتصال بقاعدة البيانات
if ($conn && !$conn->connect_error) {
    $stmt_restaurant_details = $conn->prepare("SELECT name, email, phone_number, logo_url, short_link_slug FROM restaurants WHERE id = ?");
    if ($stmt_restaurant_details) {
        $stmt_restaurant_details->bind_param("i", $restaurant_id_session);
        if ($stmt_restaurant_details->execute()) {
            $result_details = $stmt_restaurant_details->get_result();
            if ($result_details->num_rows == 1) {
                $restaurant_details = $result_details->fetch_assoc();
                
                $current_restaurant_name = htmlspecialchars($restaurant_details['name'] ?? 'اسم المطعم غير محدد');
                $_SESSION['restaurant_name'] = $restaurant_details['name'] ?? $current_restaurant_name; 
                
                $current_email = htmlspecialchars($restaurant_details['email'] ?? ''); 
                $current_phone = htmlspecialchars($restaurant_details['phone_number'] ?? '');
                $current_logo_url = htmlspecialchars($restaurant_details['logo_url'] ?? '');
                $current_slug = htmlspecialchars($restaurant_details['short_link_slug'] ?? ''); 
            } else {
                $db_fetch_error_message = "خطأ: لم يتم العثور على بيانات المطعم المسجل (ID: " . $restaurant_id_session . "). يرجى التأكد من صحة حسابك أو الاتصال بالدعم.";
                error_log("Dashboard Error: Restaurant ID " . $restaurant_id_session . " not found in database for active session.");
                // في هذه الحالة، قد ترغب في تسجيل خروج المستخدم لأن هناك عدم تطابق بين الجلسة وقاعدة البيانات
                // unset($_SESSION['logged_in']); unset($_SESSION['restaurant_id']); unset($_SESSION['restaurant_name']);
                // header("Location: login.php?error=session_mismatch");
                // exit;
            }
        } else {
            $db_fetch_error_message = "خطأ فني: فشل في تنفيذ استعلام جلب بيانات المطعم.";
            error_log("SQL Execute Error (dashboard get details): " . $stmt_restaurant_details->error);
        }
        $stmt_restaurant_details->close();
    } else {
        $db_fetch_error_message = "خطأ فني: فشل في إعداد استعلام جلب بيانات المطعم.";
        error_log("SQL Prepare Error (dashboard get details): " . $conn->error);
    }
    $conn->close(); 
} else {
    // فشل الاتصال الأساسي بقاعدة البيانات (من $conn في database.php)
    $db_fetch_error_message = "خطأ حرج: لا يمكن الاتصال بقاعدة البيانات. يرجى مراجعة ملف config/database.php أو الاتصال بالدعم.";
    error_log("Dashboard Error: Database connection object not available or connection failed. Error: " . ($conn ? $conn->connect_error : "Unknown connection error"));
    // لا يمكن المتابعة بدون قاعدة بيانات
}


// بناء رابط المنيو المباشر
// استخدم الصيغة التي تتوافق مع إعدادات نطاقك ومسار ملف menu.php
// الصيغة لـ m.sa.bio/m/menu.php?slug=...
$fixed_base_url = "https://m.sa.bio/m/"; 
$direct_menu_link = !empty($current_slug) ? ($fixed_base_url . "menu.php?slug=" . urlencode($current_slug)) : '#';


// جلب رسائل الحالة من عمليات التحديث
$message_from_handler = isset($_GET['message']) ? htmlspecialchars(urldecode($_GET['message'])) : '';
$message_type_from_handler = isset($_GET['message_type']) ? htmlspecialchars($_GET['message_type']) : '';

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة تحكم المطعم - <?php echo $current_restaurant_name; ?></title>
    <link rel="stylesheet" href="css/admin_styles.css"> </head>
<body>

    <nav class="navbar">
        <h1>لوحة تحكم: <?php echo $current_restaurant_name; ?></h1>
        <a href="logout.php">تسجيل الخروج</a>
    </nav>

    <div class="main-container">
        <aside class="sidebar">
            <h2>القائمة الرئيسية</h2>
            <ul>
                <li><a href="dashboard.php" class="active">لوحة التحكم الرئيسية</a></li>
                <li><a href="manage_sections.php">إدارة أقسام المنيو</a></li>
                <li><a href="manage_categories.php">إدارة تصنيفات المنيو</a></li>
                <li><a href="manage_items.php">إدارة أصناف المنيو</a></li>
                <li><a href="view_orders.php">عرض الطلبات</a></li> 
            </ul>
        </aside>

        <main class="content-area">
            <div class="welcome-message">
                أهلاً بك مجددًا، <?php echo $current_restaurant_name; ?>!
            </div>

            <?php 
            // عرض رسالة الخطأ المتعلقة بجلب البيانات من قاعدة البيانات إذا وجدت
            if (!empty($db_fetch_error_message)): ?>
                <div class="message error"><?php echo $db_fetch_error_message; ?></div>
            <?php endif; ?>

            <?php 
            // عرض رسائل الحالة القادمة من الصفحات الأخرى
            if (!empty($message_from_handler)): ?>
                <div class="message <?php echo htmlspecialchars($message_type_from_handler); ?>"><?php echo $message_from_handler; ?></div>
            <?php endif; ?>

            <?php 
            // لا تعرض أقسام المنيو والتعديل إذا كان هناك خطأ أساسي في جلب بيانات المطعم أو إذا كان الـ slug فارغًا
            if (empty($db_fetch_error_message) && !empty($current_slug)): 
            ?>
                <div class="dashboard-section">
                    <h3>رابط المنيو الخاص بك</h3>
                    <p>شارك هذا الرابط مع زبائنك لعرض المنيو الخاص بمطعمك:</p>
                    <div class="menu-link-display">
                        <a href="<?php echo htmlspecialchars($direct_menu_link); ?>" target="_blank"><?php echo htmlspecialchars($direct_menu_link); ?></a>
                    </div>
                    <button class="copy-btn" onclick="copyToClipboard('<?php echo htmlspecialchars($direct_menu_link, ENT_QUOTES, 'UTF-8'); ?>')">نسخ الرابط</button>
                    <p id="copy-status" style="font-size:0.9em; color:green; margin-top:5px;"></p>
                </div>

                <div class="dashboard-section">
                    <h3>تعديل بيانات المطعم</h3>
                    <form action="handle_update_profile.php" method="POST">
                        <label for="name">اسم المطعم:</label>
                        <input type="text" id="name" name="restaurant_name" value="<?php echo $current_restaurant_name; ?>" required>

                        <label for="email">البريد الإلكتروني (لتسجيل الدخول):</label>
                        <input type="email" id="email" name="email" value="<?php echo $current_email; ?>" required>

                        <label for="short_link_slug">اسم الرابط القصير (انجليزي، بدون مسافات، مثال: my-restaurant):</label>
                        <input type="text" id="short_link_slug" name="short_link_slug" value="<?php echo $current_slug; ?>" required pattern="[a-z0-9-]+" title="أحرف إنجليزية صغيرة، أرقام، وشرطات فقط">
                        <small>هذا الجزء سيظهر في رابط المنيو. مثال: .../menu.php?slug=<strong><?php echo $current_slug; ?></strong></small><br><br>

                        <label for="phone_number">رقم الهاتف (اختياري):</label>
                        <input type="text" id="phone_number" name="phone_number" value="<?php echo $current_phone; ?>">

                        <label for="logo_url">رابط صورة شعار المطعم (اختياري، يجب أن يكون رابط URL كامل):</label>
                        <input type="url" id="logo_url" name="logo_url" value="<?php echo $current_logo_url; ?>" placeholder="https://example.com/logo.png">
                        <?php if ($current_logo_url): ?>
                            <p><small>الشعار الحالي:</small><br><img src="<?php echo $current_logo_url; ?>" alt="الشعار الحالي" style="max-height: 50px; margin-top:5px; border:1px solid #ddd; padding:2px;"></p>
                        <?php endif; ?>
                        
                        <input type="submit" name="update_profile" value="حفظ التعديلات">
                    </form>
                </div>
            <?php elseif (empty($db_fetch_error_message) && empty($current_slug)): ?>
                 <p class="message info">يرجى إكمال بيانات مطعمك من خلال نموذج "تعديل بيانات المطعم" (إذا كان متاحًا)، خاصة "اسم الرابط القصير"، لتتمكن من عرض رابط المنيو.</p>
            <?php endif; ?>
        </main>
    </div>
    <script>
        function copyToClipboard(text) {
            if (navigator.clipboard && navigator.clipboard.writeText) {
                navigator.clipboard.writeText(text).then(function() {
                    document.getElementById('copy-status').textContent = 'تم نسخ الرابط!';
                    setTimeout(function(){ document.getElementById('copy-status').textContent = ''; }, 2000);
                }, function(err) {
                    document.getElementById('copy-status').textContent = 'فشل النسخ!';
                    console.error('Could not copy text: ', err);
                });
            } else {
                // حل بديل للمتصفحات القديمة أو سياقات HTTPS غير الآمنة (أقل أمانًا)
                var textArea = document.createElement("textarea");
                textArea.value = text;
                textArea.style.position="fixed";  // Remove scrollbars
                document.body.appendChild(textArea);
                textArea.focus();
                textArea.select();
                try {
                    var successful = document.execCommand('copy');
                    var msg = successful ? 'تم نسخ الرابط!' : 'فشل النسخ!';
                    document.getElementById('copy-status').textContent = msg;
                    setTimeout(function(){ document.getElementById('copy-status').textContent = ''; }, 2000);
                } catch (err) {
                    document.getElementById('copy-status').textContent = 'فشل النسخ!';
                    console.error('Fallback: Could not copy text: ', err);
                }
                document.body.removeChild(textArea);
            }
        }
    </script>
</body>
</html>